// BetterMathspace v3 — Popup JS
document.addEventListener('DOMContentLoaded', () => {
  chrome.storage.sync.get(null, S => {
    const xp = S.currentXP || 0;
    const lv = Math.floor(xp / 100) + 1;
    const inLv = xp % 100;

    document.getElementById('lvLabel').textContent   = `Level ${lv}`;
    document.getElementById('xpLabel').textContent   = `${inLv} / 100 XP`;
    document.getElementById('xpBar').style.width     = inLv + '%';
    document.getElementById('pStreak').textContent   = S.currentStreak || 0;
    document.getElementById('pAnswered').textContent = S.totalAnswered  || 0;
    document.getElementById('pBadges').textContent   = (S.achievements || []).length;
    document.getElementById('darkChip').textContent  = S.darkMode ? '🌙 Dark' : '☀️ Light';
    if (S.darkMode) document.getElementById('darkChip').style.color = '#60a5fa';

    const names = { '#00C896':'Teal','#8B5CF6':'Violet','#F43F5E':'Crimson','#0EA5E9':'Ocean','#F59E0B':'Solar','#EC4899':'Sakura','#00FF41':'Matrix','#67E8F9':'Ice' };
    const acc = S.accentColor || '#00C896';
    document.getElementById('themeChip').textContent = '💚 ' + (names[acc] || 'Custom');
    document.getElementById('themeChip').style.color = acc;
  });

  document.getElementById('openSettings')?.addEventListener('click', () => chrome.runtime.openOptionsPage());
  document.getElementById('btnSettings')?.addEventListener('click', () => chrome.runtime.openOptionsPage());

  document.getElementById('btnDark')?.addEventListener('click', () => {
    chrome.storage.sync.get(['darkMode'], ({ darkMode }) => {
      chrome.storage.sync.set({ darkMode: !darkMode });
      window.close();
    });
  });

  document.getElementById('btnFocus')?.addEventListener('click', () => {
    chrome.storage.sync.get(['focusMode'], ({ focusMode }) => {
      chrome.storage.sync.set({ focusMode: !focusMode });
      window.close();
    });
  });

  document.getElementById('btnDesmos')?.addEventListener('click', () => {
    chrome.tabs.create({ url: 'https://www.desmos.com/calculator' });
  });
});

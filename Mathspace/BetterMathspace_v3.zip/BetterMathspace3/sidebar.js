/* ================================================================
   BetterMathspace v3 — Integrated Sidebar Content Script
   Injects a full sidebar directly into Mathspace
   ================================================================ */
;(function () {
  'use strict';
  if (document.getElementById('bm-root')) return; // prevent double-inject

  // ── CONSTANTS ───────────────────────────────────────────────────
  const ACCENT_THEMES = {
    cyber:   '#00C896',
    violet:  '#8B5CF6',
    crimson: '#F43F5E',
    ocean:   '#0EA5E9',
    solar:   '#F59E0B',
    sakura:  '#EC4899',
    matrix:  '#00FF41',
    ice:     '#67E8F9',
  };

  const QUOTES = [
    { q: "The only way to learn mathematics is to do mathematics.", a: "Paul Halmos" },
    { q: "Mathematics is not about numbers — it's about understanding.", a: "W. Thurston" },
    { q: "Pure mathematics is the world's best game.", a: "R.J. Trudeau" },
    { q: "Every problem has a solution. You just have to find it.", a: "Unknown" },
    { q: "Hard work beats talent when talent doesn't work hard.", a: "Tim Notke" },
    { q: "Math is the shorthand of the universe.", a: "Unknown" },
    { q: "Mistakes are proof you are trying.", a: "Unknown" },
    { q: "The more you practice, the luckier you get.", a: "Gary Player" },
    { q: "Without mathematics there's nothing you can do.", a: "Shakuntala Devi" },
    { q: "Small steps every day lead to big results.", a: "Unknown" },
    { q: "In the middle of difficulty lies opportunity.", a: "A. Einstein" },
    { q: "Believe you can and you're halfway there.", a: "T. Roosevelt" },
  ];

  const ACHIEVEMENTS = [
    { id:'first',      icon:'🌱', name:'First Step',     desc:'Answer 1st question',    check: s => s.totalAnswered >= 1    },
    { id:'ten',        icon:'🔢', name:'Double Digits',  desc:'10 questions',           check: s => s.totalAnswered >= 10   },
    { id:'fifty',      icon:'🏃', name:'On A Roll',      desc:'50 questions',           check: s => s.totalAnswered >= 50   },
    { id:'century',    icon:'💯', name:'Century',        desc:'100 questions',          check: s => s.totalAnswered >= 100  },
    { id:'streak3',    icon:'🔥', name:'On Fire',        desc:'3-day streak',           check: s => s.currentStreak >= 3    },
    { id:'streak7',    icon:'⚡', name:'Week Warrior',   desc:'7-day streak',           check: s => s.currentStreak >= 7    },
    { id:'streak30',   icon:'👑', name:'Unstoppable',    desc:'30-day streak',          check: s => s.currentStreak >= 30   },
    { id:'xp100',      icon:'⭐', name:'XP Rookie',      desc:'Earn 100 XP',            check: s => s.currentXP >= 100      },
    { id:'xp500',      icon:'🌟', name:'XP Hunter',      desc:'Earn 500 XP',            check: s => s.currentXP >= 500      },
    { id:'xp1000',     icon:'💎', name:'XP Legend',      desc:'Earn 1000 XP',           check: s => s.currentXP >= 1000     },
    { id:'level5',     icon:'🚀', name:'Rising Star',    desc:'Reach Level 5',          check: s => s.currentLevel >= 5     },
    { id:'level10',    icon:'🏆', name:'Pro',            desc:'Reach Level 10',         check: s => s.currentLevel >= 10    },
    { id:'nightowl',   icon:'🦉', name:'Night Owl',      desc:'Study after 9pm',        check: () => new Date().getHours() >= 21 },
    { id:'earlybird',  icon:'🐦', name:'Early Bird',     desc:'Study before 7am',       check: () => new Date().getHours() < 7  },
  ];

  // ── STATE ───────────────────────────────────────────────────────
  let S = {};
  let pomLeft = 0, pomRunning = false, pomTimer = null;
  let activeSection = 'dashboard';
  let lastAnswerId = '';
  let sessionStart = Date.now();

  // ── BOOT ────────────────────────────────────────────────────────
  chrome.storage.sync.get(null, data => {
    S = data;
    buildSidebar();
    applySettings();
    updateStreak();
    if (S.quotesEnabled) setTimeout(showQuote, 2000);
    if (S.progressBar)   buildProgressBar();
    if (S.breakReminder) startBreakTimer();
    if (S.hintGlow)      watchHints();
    if (S.questionDetect)watchAnswers();
    if (S.smoothScroll)  document.documentElement.style.scrollBehavior = 'smooth';
    trackSession();
  });

  chrome.storage.onChanged.addListener(changes => {
    for (const [k, {newValue}] of Object.entries(changes)) S[k] = newValue;
    applySettings();
    refreshSidebar();
  });

  // ════════════════════════════════════════════════════════════════
  //  SIDEBAR BUILD
  // ════════════════════════════════════════════════════════════════
  function buildSidebar() {
    // Inject fonts + sidebar CSS
    injectStyles();

    // Root container
    const root = document.createElement('div');
    root.id = 'bm-root';
    root.innerHTML = `
      <!-- Toggle Tab -->
      <button id="bm-tab" title="BetterMathspace" aria-label="Toggle BetterMathspace sidebar">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
          <path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z" fill="currentColor"/>
        </svg>
        <span id="bm-tab-label">BM</span>
      </button>

      <!-- Sidebar Panel -->
      <div id="bm-sidebar">

        <!-- Header -->
        <div class="bm-sidebar-header">
          <div class="bm-logo-row">
            <div class="bm-logo-gem">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                <path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z" fill="currentColor"/>
              </svg>
            </div>
            <div class="bm-logo-text">
              <div class="bm-logo-title">BetterMathspace</div>
              <div class="bm-logo-sub">v3.0</div>
            </div>
          </div>
          <button class="bm-close-btn" id="bm-close">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none"><path d="M18 6L6 18M6 6l12 12" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"/></svg>
          </button>
        </div>

        <!-- Profile Banner -->
        <div class="bm-profile-banner" id="bm-profile-banner">
          <div class="bm-avatar-wrap" id="bm-avatar-outer">
            <div class="bm-avatar" id="bm-avatar">
              <svg width="28" height="28" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="8" r="4" fill="currentColor"/><path d="M4 20c0-4 3.6-7 8-7s8 3 8 7" fill="currentColor"/></svg>
            </div>
          </div>
          <div class="bm-profile-info">
            <div class="bm-profile-name">Mathspace Student</div>
            <div class="bm-xp-pill" id="bm-xp-pill">⚡ Lv.1 · 0 XP</div>
          </div>
        </div>

        <!-- XP Bar -->
        <div class="bm-xp-bar-wrap">
          <div class="bm-xp-track">
            <div class="bm-xp-fill" id="bm-xp-bar"></div>
          </div>
          <div class="bm-xp-meta">
            <span id="bm-xp-label">0 / 100 XP to next level</span>
            <span id="bm-streak-label">🔥 <span id="bm-streak-count">0</span>d</span>
          </div>
        </div>

        <!-- Nav Pills -->
        <div class="bm-nav">
          <button class="bm-nav-btn active" data-section="dashboard">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none"><rect x="3" y="3" width="7" height="7" rx="1" fill="currentColor"/><rect x="14" y="3" width="7" height="7" rx="1" fill="currentColor"/><rect x="3" y="14" width="7" height="7" rx="1" fill="currentColor"/><rect x="14" y="14" width="7" height="7" rx="1" fill="currentColor"/></svg>
            Dashboard
          </button>
          <button class="bm-nav-btn" data-section="tools">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none"><path d="M14.7 6.3a1 1 0 000 1.4l1.6 1.6a1 1 0 001.4 0l3.77-3.77a6 6 0 01-7.94 7.94l-6.91 6.91a2.12 2.12 0 01-3-3l6.91-6.91a6 6 0 017.94-7.94l-3.76 3.76z" fill="currentColor"/></svg>
            Tools
          </button>
          <button class="bm-nav-btn" data-section="appearance">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="4" fill="currentColor"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>
            Appearance
          </button>
          <button class="bm-nav-btn" data-section="achievements">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none"><path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z" fill="currentColor"/></svg>
            Badges
          </button>
        </div>

        <!-- Scrollable Content -->
        <div class="bm-content" id="bm-content">

          <!-- DASHBOARD SECTION -->
          <div class="bm-section" id="bm-sec-dashboard">

            <!-- Stats Row -->
            <div class="bm-stats-row">
              <div class="bm-stat-card">
                <div class="bm-stat-icon">📚</div>
                <div class="bm-stat-val" id="bm-stat-answered">0</div>
                <div class="bm-stat-lbl">Answered</div>
              </div>
              <div class="bm-stat-card">
                <div class="bm-stat-icon">✅</div>
                <div class="bm-stat-val" id="bm-stat-correct">0</div>
                <div class="bm-stat-lbl">Correct</div>
              </div>
              <div class="bm-stat-card">
                <div class="bm-stat-icon">⏰</div>
                <div class="bm-stat-val" id="bm-stat-mins">0</div>
                <div class="bm-stat-lbl">Mins today</div>
              </div>
            </div>

            <!-- Pomodoro Timer -->
            <div class="bm-card" id="bm-pom-card">
              <div class="bm-card-head">
                <div class="bm-card-title">
                  <span>🍅</span> Pomodoro
                </div>
                <div class="bm-pom-badge" id="bm-pom-badge">WORK</div>
              </div>
              <div class="bm-pom-display" id="bm-pom-display">25:00</div>
              <div class="bm-pom-ring-wrap">
                <svg class="bm-pom-ring" viewBox="0 0 100 100">
                  <circle cx="50" cy="50" r="44" fill="none" stroke="currentColor" stroke-width="3" class="bm-pom-track"/>
                  <circle cx="50" cy="50" r="44" fill="none" stroke-width="4" stroke-linecap="round"
                    stroke-dasharray="276.46" stroke-dashoffset="0"
                    class="bm-pom-arc" id="bm-pom-arc"/>
                </svg>
              </div>
              <div class="bm-pom-controls">
                <button class="bm-pom-btn" id="bm-pom-play">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M5 3l14 9-14 9V3z" fill="currentColor"/></svg>
                </button>
                <button class="bm-pom-btn bm-pom-reset" id="bm-pom-reset">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none"><path d="M1 4v6h6M23 20v-6h-6" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M20.49 9A9 9 0 005.64 5.64L1 10m22 4l-4.64 4.36A9 9 0 013.51 15" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
                </button>
              </div>
            </div>

            <!-- Quick Notes -->
            <div class="bm-card" id="bm-notes-card">
              <div class="bm-card-head">
                <div class="bm-card-title"><span>📝</span> Quick Notes</div>
                <button class="bm-card-action" id="bm-notes-save-btn">Save</button>
              </div>
              <textarea class="bm-notes-ta" id="bm-notes-ta" placeholder="Jot formulas, working, ideas…&#10;&#10;Auto-saves as you type"></textarea>
            </div>

            <!-- Pinned Links -->
            <div class="bm-card" id="bm-links-card">
              <div class="bm-card-head">
                <div class="bm-card-title"><span>📌</span> Quick Links</div>
                <button class="bm-card-action" id="bm-open-settings">Edit</button>
              </div>
              <div class="bm-links-list" id="bm-links-list"></div>
            </div>

          </div><!-- /dashboard -->

          <!-- TOOLS SECTION -->
          <div class="bm-section bm-hidden" id="bm-sec-tools">

            <!-- Focus Mode -->
            <div class="bm-card">
              <div class="bm-card-head">
                <div class="bm-card-title"><span>🎯</span> Focus Mode</div>
                <label class="bm-toggle">
                  <input type="checkbox" id="bm-t-focus">
                  <span class="bm-toggle-track"></span>
                </label>
              </div>
              <div class="bm-card-desc">Hides navigation so only the maths is visible. <span class="bm-kbd">Ctrl+Shift+F</span></div>
            </div>

            <!-- Dark Mode -->
            <div class="bm-card">
              <div class="bm-card-head">
                <div class="bm-card-title"><span>🌙</span> Dark Mode</div>
                <label class="bm-toggle">
                  <input type="checkbox" id="bm-t-dark">
                  <span class="bm-toggle-track"></span>
                </label>
              </div>
              <div class="bm-card-desc">Applies a dark overlay to the entire Mathspace interface.</div>
            </div>

            <!-- Hint Glow -->
            <div class="bm-card">
              <div class="bm-card-head">
                <div class="bm-card-title"><span>💡</span> Hint Glow</div>
                <label class="bm-toggle">
                  <input type="checkbox" id="bm-t-hint">
                  <span class="bm-toggle-track"></span>
                </label>
              </div>
              <div class="bm-card-desc">Adds a glowing highlight to hint elements.</div>
            </div>

            <!-- Progress Bar -->
            <div class="bm-card">
              <div class="bm-card-head">
                <div class="bm-card-title"><span>📊</span> Progress Bar</div>
                <label class="bm-toggle">
                  <input type="checkbox" id="bm-t-progress">
                  <span class="bm-toggle-track"></span>
                </label>
              </div>
              <div class="bm-card-desc">Animated gradient bar at the top of every page.</div>
            </div>

            <!-- Break Reminder -->
            <div class="bm-card">
              <div class="bm-card-head">
                <div class="bm-card-title"><span>🔔</span> Break Reminder</div>
                <label class="bm-toggle">
                  <input type="checkbox" id="bm-t-break">
                  <span class="bm-toggle-track"></span>
                </label>
              </div>
              <div class="bm-card-desc">Notifies you to rest every <strong id="bm-break-mins">30</strong> minutes.</div>
            </div>

            <!-- Confetti -->
            <div class="bm-card">
              <div class="bm-card-head">
                <div class="bm-card-title"><span>🎉</span> Confetti</div>
                <label class="bm-toggle">
                  <input type="checkbox" id="bm-t-confetti">
                  <span class="bm-toggle-track"></span>
                </label>
              </div>
              <div class="bm-card-desc">Shoots confetti on correct answers and achievements.</div>
            </div>

            <!-- Sound -->
            <div class="bm-card">
              <div class="bm-card-head">
                <div class="bm-card-title"><span>🔊</span> Sound Effects</div>
                <label class="bm-toggle">
                  <input type="checkbox" id="bm-t-sound">
                  <span class="bm-toggle-track"></span>
                </label>
              </div>
              <div class="bm-card-desc">Plays chimes on level-up and achievements.</div>
            </div>

            <!-- Keyboard shortcuts help -->
            <div class="bm-card">
              <div class="bm-card-head">
                <div class="bm-card-title"><span>⌨️</span> Shortcuts</div>
              </div>
              <div class="bm-shortcuts">
                <div class="bm-sc-row"><span>Toggle Sidebar</span><div><span class="bm-kbd">Alt+B</span></div></div>
                <div class="bm-sc-row"><span>Focus Mode</span><div><span class="bm-kbd">Ctrl+Shift+F</span></div></div>
                <div class="bm-sc-row"><span>Open Settings</span><div><span class="bm-kbd">Alt+S</span></div></div>
              </div>
            </div>

          </div><!-- /tools -->

          <!-- APPEARANCE SECTION -->
          <div class="bm-section bm-hidden" id="bm-sec-appearance">

            <!-- Theme -->
            <div class="bm-card">
              <div class="bm-card-head"><div class="bm-card-title"><span>🎨</span> Accent Color</div></div>
              <div class="bm-theme-grid" id="bm-theme-grid">
                <!-- filled by JS -->
              </div>
            </div>

            <!-- Profile Picture -->
            <div class="bm-card">
              <div class="bm-card-head"><div class="bm-card-title"><span>🧑</span> Profile Picture</div></div>
              <div class="bm-pfp-row">
                <div class="bm-pfp-preview" id="bm-pfp-preview-sm">
                  <svg width="22" height="22" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="8" r="4" fill="currentColor"/><path d="M4 20c0-4 3.6-7 8-7s8 3 8 7" fill="currentColor"/></svg>
                </div>
                <label class="bm-upload-btn" for="bm-pfp-input">
                  Upload Photo
                  <input type="file" id="bm-pfp-input" accept="image/*" style="display:none">
                </label>
                <button class="bm-remove-btn" id="bm-pfp-remove">Remove</button>
              </div>
            </div>

            <!-- Background -->
            <div class="bm-card">
              <div class="bm-card-head"><div class="bm-card-title"><span>🌌</span> Background Image</div></div>
              <input class="bm-input" type="text" id="bm-bg-url" placeholder="Paste image URL…">
              <div class="bm-input-row" style="margin-top:8px">
                <button class="bm-btn-sm" id="bm-bg-apply">Apply</button>
                <button class="bm-btn-sm bm-btn-ghost" id="bm-bg-clear">Clear</button>
              </div>
            </div>

            <!-- Custom CSS -->
            <div class="bm-card">
              <div class="bm-card-head">
                <div class="bm-card-title"><span>💻</span> Custom CSS</div>
                <button class="bm-card-action" id="bm-css-save">Save</button>
              </div>
              <textarea class="bm-notes-ta bm-css-ta" id="bm-css-ta" placeholder="/* Your CSS */&#10;.some-class { color: red !important; }"></textarea>
            </div>

            <!-- More in settings -->
            <button class="bm-full-settings-btn" id="bm-open-settings-2">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none"><path d="M12 15a3 3 0 100-6 3 3 0 000 6z" fill="currentColor"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83-2.83l.06-.06A1.65 1.65 0 004.68 15a1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 012.83-2.83l.06.06A1.65 1.65 0 009 4.68a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 2.83l-.06.06A1.65 1.65 0 0019.4 9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z" fill="currentColor"/></svg>
              Open Full Settings
            </button>

          </div><!-- /appearance -->

          <!-- ACHIEVEMENTS SECTION -->
          <div class="bm-section bm-hidden" id="bm-sec-achievements">
            <div class="bm-ach-grid" id="bm-ach-grid"></div>
          </div>

        </div><!-- /bm-content -->

        <!-- Footer -->
        <div class="bm-sidebar-footer">
          <button class="bm-footer-btn" id="bm-open-settings-footer">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none"><path d="M12 15a3 3 0 100-6 3 3 0 000 6z" fill="currentColor"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83-2.83l.06-.06A1.65 1.65 0 004.68 15a1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 012.83-2.83l.06.06A1.65 1.65 0 009 4.68a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 2.83l-.06.06A1.65 1.65 0 0019.4 9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z" fill="currentColor"/></svg>
            Settings
          </button>
          <span class="bm-footer-ver">v3.0</span>
        </div>

      </div><!-- /bm-sidebar -->
    `;

    document.body.appendChild(root);

    // Wire up everything
    wireTabBtn();
    wireNav();
    wireTools();
    wirePomodoro();
    wireNotes();
    wireLinks();
    wireAppearance();
    wireSettings();
    wireKeyboard();
    buildThemeGrid();
    buildAchievements();
    refreshSidebar();

    // Restore open state
    if (S.sidebarOpen) openSidebar();
  }

  // ── SIDEBAR STYLES (injected) ────────────────────────────────────
  function injectStyles() {
    const style = document.createElement('style');
    style.id = 'bm-styles';
    style.textContent = getSidebarCSS();
    document.head.appendChild(style);
  }

  function getSidebarCSS() {
    return `
/* BetterMathspace Sidebar Styles */
#bm-root {
  font-family: 'Proxima Nova', -apple-system, BlinkMacSystemFont, sans-serif;
  --bm-acc: ${S.accentColor || '#00C896'};
  --bm-acc-rgb: 0,200,150;
  --bm-sidebar-w: 280px;
  --bm-t: 0.28s cubic-bezier(.4,0,.2,1);
}

/* Toggle tab */
#bm-tab {
  position: fixed;
  top: 50%;
  left: 0;
  transform: translateY(-50%);
  z-index: 2147483640;
  background: var(--bm-acc);
  color: #000;
  border: none;
  border-radius: 0 10px 10px 0;
  padding: 12px 8px;
  cursor: pointer;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 5px;
  box-shadow: 2px 0 16px rgba(0,0,0,0.3), 0 0 20px rgba(var(--bm-acc-rgb),0.3);
  transition: all var(--bm-t);
  font-weight: 700;
  font-size: 0.6rem;
  letter-spacing: 0.04em;
}
#bm-tab:hover {
  padding-left: 12px;
  box-shadow: 4px 0 24px rgba(0,0,0,0.4), 0 0 30px rgba(var(--bm-acc-rgb),0.5);
}
#bm-tab-label { writing-mode: vertical-rl; text-orientation: mixed; font-weight: 800; font-size: 0.55rem; letter-spacing: 0.15em; }

/* Sidebar */
#bm-sidebar {
  position: fixed;
  top: 0; left: 0; bottom: 0;
  width: var(--bm-sidebar-w);
  z-index: 2147483641;
  background: #0e0e1a;
  border-right: 1px solid rgba(255,255,255,0.07);
  display: flex;
  flex-direction: column;
  transform: translateX(-100%);
  transition: transform var(--bm-t);
  box-shadow: 4px 0 40px rgba(0,0,0,0.6);
  overflow: hidden;
}
#bm-sidebar.bm-open {
  transform: translateX(0);
}

/* Header */
.bm-sidebar-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 14px 16px 12px;
  border-bottom: 1px solid rgba(255,255,255,0.07);
  background: rgba(var(--bm-acc-rgb),0.05);
  flex-shrink: 0;
}
.bm-logo-row { display: flex; align-items: center; gap: 10px; }
.bm-logo-gem {
  width: 32px; height: 32px;
  background: linear-gradient(135deg, var(--bm-acc), #3b82f6);
  border-radius: 8px;
  display: flex; align-items: center; justify-content: center;
  color: #000;
  box-shadow: 0 0 16px rgba(var(--bm-acc-rgb),0.4);
  flex-shrink: 0;
}
.bm-logo-title {
  font-size: 0.88rem; font-weight: 800;
  background: linear-gradient(90deg, var(--bm-acc), #60a5fa);
  -webkit-background-clip: text; -webkit-text-fill-color: transparent;
  background-clip: text; line-height: 1.1;
}
.bm-logo-sub { font-size: 0.6rem; color: rgba(255,255,255,0.4); letter-spacing: 0.08em; }
.bm-close-btn {
  background: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.1);
  border-radius: 8px; padding: 6px; cursor: pointer; color: rgba(255,255,255,0.5);
  display: flex; align-items: center; justify-content: center;
  transition: all 0.2s;
}
.bm-close-btn:hover { background: rgba(255,255,255,0.1); color: #fff; }

/* Profile banner */
.bm-profile-banner {
  display: flex; align-items: center; gap: 12px;
  padding: 14px 16px 10px;
  flex-shrink: 0;
}
.bm-avatar-wrap { position: relative; flex-shrink: 0; }
.bm-avatar {
  width: 46px; height: 46px; border-radius: 50%;
  background: rgba(var(--bm-acc-rgb),0.15);
  border: 2px solid var(--bm-acc);
  display: flex; align-items: center; justify-content: center;
  color: var(--bm-acc); overflow: hidden;
  box-shadow: 0 0 16px rgba(var(--bm-acc-rgb),0.3);
}
.bm-avatar img { width: 100%; height: 100%; object-fit: cover; border-radius: 50%; }
.bm-profile-name { font-size: 0.82rem; font-weight: 700; color: rgba(255,255,255,0.9); }
.bm-xp-pill {
  font-size: 0.7rem; font-weight: 700; color: var(--bm-acc);
  background: rgba(var(--bm-acc-rgb),0.12);
  border: 1px solid rgba(var(--bm-acc-rgb),0.25);
  border-radius: 20px; padding: 2px 9px; display: inline-block; margin-top: 4px;
}

/* XP bar */
.bm-xp-bar-wrap { padding: 0 16px 12px; flex-shrink: 0; }
.bm-xp-track {
  height: 5px; background: rgba(255,255,255,0.08);
  border-radius: 5px; overflow: hidden; margin-bottom: 6px;
}
.bm-xp-fill {
  height: 100%; width: 0%;
  background: linear-gradient(90deg, var(--bm-acc), #60a5fa);
  border-radius: 5px;
  box-shadow: 0 0 8px rgba(var(--bm-acc-rgb),0.5);
  transition: width 0.8s cubic-bezier(.4,0,.2,1);
}
.bm-xp-meta {
  display: flex; justify-content: space-between;
  font-size: 0.65rem; color: rgba(255,255,255,0.4);
}

/* Nav */
.bm-nav {
  display: grid; grid-template-columns: repeat(4,1fr);
  gap: 0; padding: 0 10px 10px;
  flex-shrink: 0;
}
.bm-nav-btn {
  display: flex; flex-direction: column; align-items: center; gap: 3px;
  padding: 7px 4px;
  background: transparent; border: none; cursor: pointer;
  color: rgba(255,255,255,0.35);
  font-family: inherit; font-size: 0.58rem; font-weight: 700;
  letter-spacing: 0.03em; text-transform: uppercase;
  border-radius: 8px; transition: all 0.18s;
}
.bm-nav-btn:hover { background: rgba(255,255,255,0.06); color: rgba(255,255,255,0.7); }
.bm-nav-btn.active {
  background: rgba(var(--bm-acc-rgb),0.12);
  color: var(--bm-acc);
}

/* Content area */
.bm-content {
  flex: 1;
  overflow-y: auto;
  padding: 4px 12px 16px;
  scrollbar-width: thin;
  scrollbar-color: rgba(255,255,255,0.1) transparent;
}
.bm-content::-webkit-scrollbar { width: 4px; }
.bm-content::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.1); border-radius: 2px; }

/* Sections */
.bm-section {}
.bm-hidden { display: none; }

/* Stats row */
.bm-stats-row { display: grid; grid-template-columns: repeat(3,1fr); gap: 7px; margin-bottom: 10px; }
.bm-stat-card {
  background: rgba(255,255,255,0.04);
  border: 1px solid rgba(255,255,255,0.07);
  border-radius: 10px; padding: 10px 6px; text-align: center;
  transition: all 0.2s;
}
.bm-stat-card:hover { border-color: rgba(var(--bm-acc-rgb),0.3); transform: translateY(-1px); }
.bm-stat-icon { font-size: 1.2rem; margin-bottom: 4px; }
.bm-stat-val { font-size: 1.15rem; font-weight: 800; color: var(--bm-acc); line-height: 1; }
.bm-stat-lbl { font-size: 0.58rem; color: rgba(255,255,255,0.35); margin-top: 3px; text-transform: uppercase; letter-spacing: 0.05em; }

/* Cards */
.bm-card {
  background: rgba(255,255,255,0.04);
  border: 1px solid rgba(255,255,255,0.07);
  border-radius: 12px; padding: 12px; margin-bottom: 9px;
  transition: border-color 0.2s;
}
.bm-card:hover { border-color: rgba(var(--bm-acc-rgb),0.2); }
.bm-card-head {
  display: flex; align-items: center; justify-content: space-between;
  margin-bottom: 8px;
}
.bm-card-title {
  display: flex; align-items: center; gap: 6px;
  font-size: 0.8rem; font-weight: 700; color: rgba(255,255,255,0.85);
}
.bm-card-desc { font-size: 0.72rem; color: rgba(255,255,255,0.35); line-height: 1.5; }
.bm-card-action {
  background: rgba(var(--bm-acc-rgb),0.1); border: 1px solid rgba(var(--bm-acc-rgb),0.25);
  border-radius: 6px; padding: 3px 9px;
  color: var(--bm-acc); font-family: inherit; font-size: 0.68rem; font-weight: 700;
  cursor: pointer; transition: all 0.2s;
}
.bm-card-action:hover { background: rgba(var(--bm-acc-rgb),0.2); }

/* Pomodoro */
.bm-pom-badge {
  font-size: 0.6rem; font-weight: 800; letter-spacing: 0.1em;
  background: rgba(var(--bm-acc-rgb),0.12); color: var(--bm-acc);
  border: 1px solid rgba(var(--bm-acc-rgb),0.25); border-radius: 10px; padding: 2px 8px;
}
.bm-pom-display {
  text-align: center;
  font-size: 2rem; font-weight: 800; color: #fff;
  letter-spacing: 0.05em; line-height: 1;
  margin: 4px 0 4px;
}
.bm-pom-ring-wrap {
  position: relative; width: 90px; height: 90px;
  margin: 0 auto 10px;
}
.bm-pom-ring { width: 100%; height: 100%; transform: rotate(-90deg); }
.bm-pom-track { color: rgba(255,255,255,0.06); }
.bm-pom-arc {
  stroke: var(--bm-acc);
  filter: drop-shadow(0 0 4px rgba(var(--bm-acc-rgb),0.6));
  transition: stroke-dashoffset 1s linear;
}
.bm-pom-controls { display: flex; justify-content: center; gap: 10px; }
.bm-pom-btn {
  width: 40px; height: 40px; border-radius: 50%;
  background: var(--bm-acc); border: none; cursor: pointer;
  display: flex; align-items: center; justify-content: center;
  color: #000; box-shadow: 0 0 16px rgba(var(--bm-acc-rgb),0.4);
  transition: all 0.2s;
}
.bm-pom-btn:hover { transform: scale(1.1); box-shadow: 0 0 24px rgba(var(--bm-acc-rgb),0.6); }
.bm-pom-reset {
  background: rgba(255,255,255,0.08); color: rgba(255,255,255,0.6);
  box-shadow: none; width: 34px; height: 34px; align-self: center;
}
.bm-pom-reset:hover { background: rgba(255,255,255,0.15); box-shadow: none; }

/* Notes */
.bm-notes-ta {
  width: 100%; min-height: 110px; resize: vertical;
  background: rgba(0,0,0,0.3); border: 1px solid rgba(255,255,255,0.08);
  border-radius: 8px; color: rgba(255,255,255,0.85);
  font-family: 'Proxima Nova', sans-serif; font-size: 0.78rem; line-height: 1.6;
  padding: 9px 10px; outline: none;
}
.bm-notes-ta:focus { border-color: rgba(var(--bm-acc-rgb),0.4); box-shadow: 0 0 0 2px rgba(var(--bm-acc-rgb),0.08); }
.bm-notes-ta::placeholder { color: rgba(255,255,255,0.2); }
.bm-css-ta { min-height: 90px; font-family: monospace !important; font-size: 0.72rem !important; }

/* Links */
.bm-links-list { display: flex; flex-direction: column; gap: 5px; }
.bm-link-item {
  display: flex; align-items: center; gap: 8px;
  padding: 7px 10px;
  background: rgba(255,255,255,0.04);
  border: 1px solid rgba(255,255,255,0.06);
  border-radius: 8px; cursor: pointer;
  text-decoration: none; color: rgba(255,255,255,0.75);
  font-size: 0.78rem; font-weight: 600;
  transition: all 0.18s;
}
.bm-link-item:hover {
  background: rgba(var(--bm-acc-rgb),0.1);
  border-color: rgba(var(--bm-acc-rgb),0.3);
  color: var(--bm-acc);
  transform: translateX(2px);
}
.bm-link-icon { font-size: 1rem; flex-shrink: 0; }
.bm-link-arrow { margin-left: auto; opacity: 0.4; font-size: 0.7rem; }

/* Toggle */
.bm-toggle { position: relative; width: 38px; height: 20px; flex-shrink: 0; cursor: pointer; }
.bm-toggle input { opacity: 0; width: 0; height: 0; }
.bm-toggle-track {
  position: absolute; inset: 0;
  background: rgba(255,255,255,0.1); border-radius: 20px;
  border: 1px solid rgba(255,255,255,0.12);
  transition: all 0.2s;
}
.bm-toggle-track::before {
  content: ''; position: absolute;
  width: 14px; height: 14px; left: 2px; top: 2px;
  background: rgba(255,255,255,0.5); border-radius: 50%;
  transition: all 0.2s;
}
.bm-toggle input:checked ~ .bm-toggle-track {
  background: rgba(var(--bm-acc-rgb),0.2); border-color: var(--bm-acc);
  box-shadow: 0 0 8px rgba(var(--bm-acc-rgb),0.3);
}
.bm-toggle input:checked ~ .bm-toggle-track::before {
  transform: translateX(18px); background: var(--bm-acc);
  box-shadow: 0 0 6px rgba(var(--bm-acc-rgb),0.6);
}

/* Shortcuts */
.bm-shortcuts { display: flex; flex-direction: column; gap: 5px; }
.bm-sc-row {
  display: flex; align-items: center; justify-content: space-between;
  font-size: 0.73rem; color: rgba(255,255,255,0.5); padding: 2px 0;
}
.bm-kbd {
  background: rgba(255,255,255,0.08); border: 1px solid rgba(255,255,255,0.12);
  border-radius: 5px; padding: 2px 6px;
  font-size: 0.65rem; font-weight: 700; color: var(--bm-acc);
  font-family: monospace;
}

/* Theme grid */
.bm-theme-grid { display: grid; grid-template-columns: repeat(4,1fr); gap: 7px; }
.bm-theme-swatch {
  aspect-ratio: 1; border-radius: 50%; border: 3px solid transparent;
  cursor: pointer; transition: all 0.2s;
}
.bm-theme-swatch:hover { transform: scale(1.15); }
.bm-theme-swatch.active { border-color: #fff; transform: scale(1.1); }

/* Profile pic row */
.bm-pfp-row { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }
.bm-pfp-preview {
  width: 44px; height: 44px; border-radius: 50%;
  background: rgba(var(--bm-acc-rgb),0.12); border: 2px solid var(--bm-acc);
  display: flex; align-items: center; justify-content: center;
  color: var(--bm-acc); overflow: hidden; flex-shrink: 0;
}
.bm-pfp-preview img { width: 100%; height: 100%; object-fit: cover; border-radius: 50%; }
.bm-upload-btn {
  flex: 1; text-align: center; padding: 7px 10px;
  background: rgba(var(--bm-acc-rgb),0.1); border: 1px solid rgba(var(--bm-acc-rgb),0.25);
  border-radius: 8px; color: var(--bm-acc); font-family: inherit;
  font-size: 0.75rem; font-weight: 700; cursor: pointer; transition: all 0.2s;
}
.bm-upload-btn:hover { background: rgba(var(--bm-acc-rgb),0.2); }
.bm-remove-btn {
  padding: 7px 10px; background: rgba(255,68,68,0.1); border: 1px solid rgba(255,68,68,0.25);
  border-radius: 8px; color: #ff6b6b; font-family: inherit;
  font-size: 0.72rem; font-weight: 700; cursor: pointer; transition: all 0.2s;
}
.bm-remove-btn:hover { background: rgba(255,68,68,0.2); }

/* Input */
.bm-input {
  width: 100%; padding: 8px 10px;
  background: rgba(0,0,0,0.3); border: 1px solid rgba(255,255,255,0.08);
  border-radius: 8px; color: rgba(255,255,255,0.85);
  font-family: inherit; font-size: 0.78rem; outline: none;
}
.bm-input:focus { border-color: rgba(var(--bm-acc-rgb),0.4); }
.bm-input::placeholder { color: rgba(255,255,255,0.2); }
.bm-input-row { display: flex; gap: 7px; }
.bm-btn-sm {
  flex: 1; padding: 7px; border-radius: 8px; border: none;
  background: var(--bm-acc); color: #000;
  font-family: inherit; font-size: 0.72rem; font-weight: 700; cursor: pointer; transition: all 0.2s;
}
.bm-btn-sm:hover { opacity: 0.85; }
.bm-btn-ghost {
  background: rgba(255,255,255,0.06) !important;
  border: 1px solid rgba(255,255,255,0.1) !important;
  color: rgba(255,255,255,0.5) !important;
}
.bm-btn-ghost:hover { background: rgba(255,255,255,0.1) !important; color: rgba(255,255,255,0.8) !important; }

/* Full settings button */
.bm-full-settings-btn {
  width: 100%; padding: 11px; border-radius: 10px; border: none;
  background: rgba(var(--bm-acc-rgb),0.1); border: 1px solid rgba(var(--bm-acc-rgb),0.2);
  color: var(--bm-acc); font-family: inherit; font-size: 0.78rem; font-weight: 700;
  cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 8px;
  transition: all 0.2s; margin-top: 6px;
}
.bm-full-settings-btn:hover { background: rgba(var(--bm-acc-rgb),0.2); }

/* Achievements grid */
.bm-ach-grid { display: grid; grid-template-columns: repeat(3,1fr); gap: 8px; padding-top: 4px; }
.bm-ach-tile {
  padding: 10px 8px; border-radius: 10px; text-align: center;
  background: rgba(255,255,255,0.04); border: 1px solid rgba(255,255,255,0.06);
  opacity: 0.3; transition: all 0.2s;
}
.bm-ach-tile.got {
  opacity: 1; border-color: rgba(var(--bm-acc-rgb),0.3);
  background: rgba(var(--bm-acc-rgb),0.06);
}
.bm-ach-tile.got:hover { transform: translateY(-2px); box-shadow: 0 6px 18px rgba(0,0,0,0.3); }
.bm-ach-em { font-size: 1.6rem; margin-bottom: 4px; }
.bm-ach-nm { font-size: 0.68rem; font-weight: 700; color: rgba(255,255,255,0.85); line-height: 1.2; }
.bm-ach-ds { font-size: 0.6rem; color: rgba(255,255,255,0.3); margin-top: 2px; line-height: 1.3; }
.bm-ach-tile.got .bm-ach-nm { color: var(--bm-acc); }

/* Footer */
.bm-sidebar-footer {
  display: flex; align-items: center; justify-content: space-between;
  padding: 10px 14px;
  border-top: 1px solid rgba(255,255,255,0.06);
  flex-shrink: 0;
}
.bm-footer-btn {
  display: flex; align-items: center; gap: 6px;
  background: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.1);
  border-radius: 8px; padding: 6px 11px;
  color: rgba(255,255,255,0.45); font-family: inherit;
  font-size: 0.72rem; font-weight: 700; cursor: pointer; transition: all 0.2s;
}
.bm-footer-btn:hover { background: rgba(255,255,255,0.1); color: rgba(255,255,255,0.8); }
.bm-footer-ver { font-size: 0.62rem; color: rgba(255,255,255,0.2); }
    `;
  }

  // ── SIDEBAR OPEN/CLOSE ───────────────────────────────────────────
  function openSidebar() {
    document.getElementById('bm-sidebar').classList.add('bm-open');
    document.body.classList.add('bm-sidebar-open-left');
    chrome.storage.sync.set({ sidebarOpen: true });
  }
  function closeSidebar() {
    document.getElementById('bm-sidebar').classList.remove('bm-open');
    document.body.classList.remove('bm-sidebar-open-left');
    chrome.storage.sync.set({ sidebarOpen: false });
  }
  function toggleSidebar() {
    const open = document.getElementById('bm-sidebar').classList.contains('bm-open');
    open ? closeSidebar() : openSidebar();
  }

  // ── WIRE BUTTONS ─────────────────────────────────────────────────
  function wireTabBtn() {
    document.getElementById('bm-tab').addEventListener('click', toggleSidebar);
    document.getElementById('bm-close').addEventListener('click', closeSidebar);
  }

  function wireNav() {
    document.querySelectorAll('.bm-nav-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.bm-nav-btn').forEach(b => b.classList.remove('active'));
        document.querySelectorAll('.bm-section').forEach(s => s.classList.add('bm-hidden'));
        btn.classList.add('active');
        activeSection = btn.dataset.section;
        const sec = document.getElementById(`bm-sec-${activeSection}`);
        if (sec) sec.classList.remove('bm-hidden');
      });
    });
  }

  function wireSettings() {
    ['bm-open-settings','bm-open-settings-2','bm-open-settings-footer'].forEach(id => {
      document.getElementById(id)?.addEventListener('click', () => chrome.runtime.openOptionsPage());
    });
  }

  function wireKeyboard() {
    document.addEventListener('keydown', e => {
      if (e.altKey && e.key === 'b') { e.preventDefault(); toggleSidebar(); }
      if (e.altKey && e.key === 's') { e.preventDefault(); chrome.runtime.openOptionsPage(); }
      if ((e.ctrlKey||e.metaKey) && e.shiftKey && e.key === 'F') {
        e.preventDefault();
        const val = !S.focusMode;
        S.focusMode = val;
        chrome.storage.sync.set({ focusMode: val });
        applyFocusMode();
        toast(`Focus Mode ${val ? 'ON 🎯' : 'OFF'}`, 'info');
      }
    });
  }

  // ── TOOLS TOGGLES ───────────────────────────────────────────────
  function wireTools() {
    const toggleMap = {
      'bm-t-focus':    ['focusMode',    (v) => { applyFocusMode(); }],
      'bm-t-dark':     ['darkMode',     (v) => { applyDarkMode(); }],
      'bm-t-hint':     ['hintGlow',     (v) => { if (v) watchHints(); }],
      'bm-t-progress': ['progressBar',  (v) => { if (v) buildProgressBar(); else removeProgressBar(); }],
      'bm-t-break':    ['breakReminder',(v) => { if (v) startBreakTimer(); else clearBreakTimer(); }],
      'bm-t-confetti': ['confettiEnabled', () => {}],
      'bm-t-sound':    ['soundEnabled',    () => {}],
    };

    for (const [id, [key, handler]] of Object.entries(toggleMap)) {
      const el = document.getElementById(id);
      if (!el) continue;
      el.checked = !!S[key];
      el.addEventListener('change', () => {
        S[key] = el.checked;
        chrome.storage.sync.set({ [key]: el.checked });
        handler(el.checked);
      });
    }
  }

  // ── POMODORO ────────────────────────────────────────────────────
  function wirePomodoro() {
    resetPom();
    document.getElementById('bm-pom-play').addEventListener('click', togglePom);
    document.getElementById('bm-pom-reset').addEventListener('click', () => {
      if (pomTimer) clearInterval(pomTimer);
      pomRunning = false; pomTimer = null;
      resetPom();
    });
  }

  function resetPom() {
    pomLeft = (S.pomodoroWork || 25) * 60;
    updatePomDisplay();
    updatePomArc(1);
    const btn = document.getElementById('bm-pom-play');
    if (btn) btn.innerHTML = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M5 3l14 9-14 9V3z" fill="currentColor"/></svg>`;
  }

  function togglePom() {
    const btn = document.getElementById('bm-pom-play');
    if (pomRunning) {
      clearInterval(pomTimer); pomRunning = false;
      btn.innerHTML = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M5 3l14 9-14 9V3z" fill="currentColor"/></svg>`;
    } else {
      pomRunning = true;
      btn.innerHTML = `<svg width="12" height="14" viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg>`;
      const total = (S.pomodoroWork || 25) * 60;
      pomTimer = setInterval(() => {
        pomLeft = Math.max(0, pomLeft - 1);
        updatePomDisplay();
        updatePomArc(pomLeft / total);
        if (pomLeft <= 0) {
          clearInterval(pomTimer); pomRunning = false;
          pomLeft = 0;
          updatePomDisplay();
          toast('🍅 Pomodoro complete! Take a break 🧘', 'success');
          awardXP(50);
          if (S.soundEnabled) chime([523,659,784,1046]);
          if (S.confettiEnabled) confetti(45);
          setTimeout(resetPom, 1500);
        }
      }, 1000);
    }
  }

  function updatePomDisplay() {
    const el = document.getElementById('bm-pom-display');
    if (!el) return;
    const m = Math.floor(pomLeft/60), s = pomLeft%60;
    el.textContent = `${pad(m)}:${pad(s)}`;
    el.style.color = pomLeft <= 60 ? '#ff6b6b' : '#fff';
  }

  function updatePomArc(fraction) {
    const arc = document.getElementById('bm-pom-arc');
    if (!arc) return;
    const circ = 276.46;
    arc.style.strokeDashoffset = circ * (1 - fraction);
  }

  function pad(n) { return String(n).padStart(2,'0'); }

  // ── NOTES ───────────────────────────────────────────────────────
  function wireNotes() {
    const ta = document.getElementById('bm-notes-ta');
    if (!ta) return;
    ta.value = S.notes || '';
    ta.addEventListener('input', () => {
      clearTimeout(window._bmNoteT);
      window._bmNoteT = setTimeout(() => {
        S.notes = ta.value;
        chrome.storage.sync.set({ notes: ta.value });
      }, 600);
    });
    document.getElementById('bm-notes-save-btn')?.addEventListener('click', () => {
      S.notes = ta.value;
      chrome.storage.sync.set({ notes: ta.value });
      toast('Notes saved ✓', 'success');
    });
  }

  // ── LINKS ───────────────────────────────────────────────────────
  function wireLinks() {
    renderLinks();
  }

  function renderLinks() {
    const list = document.getElementById('bm-links-list');
    if (!list) return;
    const links = S.pinnedLinks || [];
    list.innerHTML = '';
    links.forEach(l => {
      const a = document.createElement('a');
      a.className = 'bm-link-item';
      a.href = l.url; a.target = '_blank'; a.rel = 'noopener';
      a.innerHTML = `<span class="bm-link-icon">${l.icon || '🔗'}</span><span>${l.label}</span><span class="bm-link-arrow">↗</span>`;
      list.appendChild(a);
    });
    if (!links.length) {
      list.innerHTML = `<div style="font-size:.72rem;color:rgba(255,255,255,.25);text-align:center;padding:8px 0">No links yet — add them in Settings</div>`;
    }
  }

  // ── APPEARANCE ──────────────────────────────────────────────────
  function wireAppearance() {
    // Profile pic upload
    document.getElementById('bm-pfp-input')?.addEventListener('change', e => {
      const file = e.target.files[0];
      if (!file || file.size > 2097152) { toast('Image too large (max 2MB)', 'error'); return; }
      const reader = new FileReader();
      reader.onload = ev => {
        S.customProfilePic = ev.target.result;
        chrome.storage.sync.set({ customProfilePic: ev.target.result });
        applyProfilePic();
      };
      reader.readAsDataURL(file);
    });

    document.getElementById('bm-pfp-remove')?.addEventListener('click', () => {
      S.customProfilePic = '';
      chrome.storage.sync.set({ customProfilePic: '' });
      applyProfilePic();
    });

    // Background
    document.getElementById('bm-bg-apply')?.addEventListener('click', () => {
      const url = document.getElementById('bm-bg-url')?.value.trim();
      S.customBackground = url;
      chrome.storage.sync.set({ customBackground: url });
      applyBackground();
    });
    document.getElementById('bm-bg-clear')?.addEventListener('click', () => {
      S.customBackground = '';
      chrome.storage.sync.set({ customBackground: '' });
      if (document.getElementById('bm-bg-url')) document.getElementById('bm-bg-url').value = '';
      applyBackground();
    });
    if (S.customBackground && document.getElementById('bm-bg-url')) {
      document.getElementById('bm-bg-url').value = S.customBackground;
    }

    // Custom CSS
    const cssTA = document.getElementById('bm-css-ta');
    if (cssTA) cssTA.value = S.customCSS || '';
    document.getElementById('bm-css-save')?.addEventListener('click', () => {
      const val = document.getElementById('bm-css-ta')?.value || '';
      S.customCSS = val;
      chrome.storage.sync.set({ customCSS: val });
      applyCustomCSS();
      toast('CSS saved ✓', 'success');
    });
  }

  function buildThemeGrid() {
    const grid = document.getElementById('bm-theme-grid');
    if (!grid) return;
    Object.entries(ACCENT_THEMES).forEach(([name, color]) => {
      const sw = document.createElement('div');
      sw.className = `bm-theme-swatch${S.accentColor === color ? ' active' : ''}`;
      sw.style.background = color;
      sw.title = name;
      sw.addEventListener('click', () => {
        document.querySelectorAll('.bm-theme-swatch').forEach(s => s.classList.remove('active'));
        sw.classList.add('active');
        S.accentColor = color;
        chrome.storage.sync.set({ accentColor: color });
        updateAccent(color);
        toast(`Theme: ${name} ✓`, 'info');
      });
      grid.appendChild(sw);
    });
  }

  function buildAchievements() {
    const grid = document.getElementById('bm-ach-grid');
    if (!grid) return;
    const got = S.achievements || [];
    grid.innerHTML = ACHIEVEMENTS.map(a => `
      <div class="bm-ach-tile${got.includes(a.id) ? ' got' : ''}" title="${a.desc}">
        <div class="bm-ach-em">${a.icon}</div>
        <div class="bm-ach-nm">${a.name}</div>
        <div class="bm-ach-ds">${a.desc}</div>
      </div>
    `).join('');
  }

  // ── APPLY SETTINGS ───────────────────────────────────────────────
  function applySettings() {
    applyDarkMode();
    applyFocusMode();
    applyProfilePic();
    applyBackground();
    applyCustomCSS();
    updateAccent(S.accentColor || '#00C896');

    // Sync tool toggles
    const map = {
      'bm-t-focus': 'focusMode', 'bm-t-dark': 'darkMode',
      'bm-t-hint': 'hintGlow', 'bm-t-progress': 'progressBar',
      'bm-t-break': 'breakReminder', 'bm-t-confetti': 'confettiEnabled',
      'bm-t-sound': 'soundEnabled',
    };
    for (const [id, key] of Object.entries(map)) {
      const el = document.getElementById(id);
      if (el) el.checked = !!S[key];
    }

    document.getElementById('bm-break-mins')?.textContent && (
      document.getElementById('bm-break-mins').textContent = S.breakInterval || 30
    );
  }

  function applyDarkMode() {
    document.body.classList.toggle('bm-dark', !!S.darkMode);
  }

  function applyFocusMode() {
    document.body.classList.toggle('bm-focus', !!S.focusMode);
    const el = document.getElementById('bm-t-focus');
    if (el) el.checked = !!S.focusMode;
  }

  function applyProfilePic() {
    const preview = document.getElementById('bm-pfp-preview-sm');
    const mainAvatar = document.getElementById('bm-avatar');
    if (S.customProfilePic) {
      // Update sidebar avatar
      [preview, mainAvatar].forEach(el => {
        if (!el) return;
        let img = el.querySelector('img');
        if (!img) { img = document.createElement('img'); el.innerHTML = ''; el.appendChild(img); }
        img.src = S.customProfilePic;
      });
      // Replace Mathspace avatars
      const sel = 'img[alt*="vatar"i],img[alt*="rofile"i],[class*="avatar"i] img,[class*="Avatar"] img,[class*="ProfileImage"i] img';
      document.querySelectorAll(sel).forEach(img => {
        if (!img.closest('#bm-root')) { img.src = S.customProfilePic; img.style.objectFit = 'cover'; }
      });
      // Watch for new avatars
      if (!window._bmPfpObserver) {
        window._bmPfpObserver = new MutationObserver(() => {
          if (!S.customProfilePic) return;
          document.querySelectorAll(sel).forEach(img => {
            if (!img.closest('#bm-root') && img.src !== S.customProfilePic) {
              img.src = S.customProfilePic;
            }
          });
        });
        window._bmPfpObserver.observe(document.body, { childList: true, subtree: true });
      }
    } else {
      // Reset sidebar avatar
      [preview, mainAvatar].forEach(el => {
        if (!el) return;
        const img = el.querySelector('img');
        if (img) { img.remove(); }
      });
    }
  }

  function applyBackground() {
    let layer = document.getElementById('bm-bg-layer');
    if (!layer) {
      layer = document.createElement('div'); layer.id = 'bm-bg-layer';
      document.body.insertBefore(layer, document.body.firstChild);
    }
    if (S.customBackground) {
      layer.style.backgroundImage = `url('${S.customBackground}')`;
      layer.style.opacity = (S.backgroundOpacity || 12) / 100;
      layer.style.filter = `blur(${S.backgroundBlur || 6}px)`;
    } else {
      layer.style.backgroundImage = '';
      layer.style.opacity = '0';
    }
  }

  function applyCustomCSS() {
    let el = document.getElementById('bm-custom-css');
    if (!el) { el = document.createElement('style'); el.id = 'bm-custom-css'; document.head.appendChild(el); }
    el.textContent = S.customCSS || '';
  }

  function updateAccent(color) {
    const root = document.getElementById('bm-root');
    if (root) root.style.setProperty('--bm-acc', color);
    document.documentElement.style.setProperty('--bm-acc', color);
    // Update CSS vars for override sheet
    const rgb = hexToRgb(color);
    if (rgb) document.getElementById('bm-root')?.style.setProperty('--bm-acc-rgb', rgb);
  }

  function hexToRgb(hex) {
    const m = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return m ? `${parseInt(m[1],16)},${parseInt(m[2],16)},${parseInt(m[3],16)}` : null;
  }

  // ── REFRESH SIDEBAR DATA ─────────────────────────────────────────
  function refreshSidebar() {
    const xp = S.currentXP || 0;
    const lv = Math.floor(xp / 100) + 1;
    const inLv = xp % 100;

    const xpPill = document.getElementById('bm-xp-pill');
    const xpBar  = document.getElementById('bm-xp-bar');
    const xpLbl  = document.getElementById('bm-xp-label');
    const strk   = document.getElementById('bm-streak-count');

    if (xpPill)  xpPill.textContent   = `⚡ Lv.${lv} · ${xp} XP`;
    if (xpBar)   xpBar.style.width    = inLv + '%';
    if (xpLbl)   xpLbl.textContent    = `${inLv} / 100 XP to next level`;
    if (strk)    strk.textContent     = S.currentStreak || 0;

    const answered = document.getElementById('bm-stat-answered');
    const correct  = document.getElementById('bm-stat-correct');
    const mins     = document.getElementById('bm-stat-mins');
    if (answered) answered.textContent = S.totalAnswered   || 0;
    if (correct)  correct.textContent  = S.totalCorrect    || 0;
    if (mins)     mins.textContent     = Math.round((Date.now() - sessionStart) / 60000);

    renderLinks();
    buildAchievements();
  }

  // ── PROGRESS BAR ────────────────────────────────────────────────
  function buildProgressBar() {
    if (document.getElementById('bm-progress')) return;
    const bar = document.createElement('div'); bar.id = 'bm-progress';
    const fill = document.createElement('div'); fill.id = 'bm-progress-fill';
    bar.appendChild(fill); document.body.appendChild(bar);
    document.addEventListener('scroll', () => {
      const pct = window.innerHeight + window.scrollY >= document.body.scrollHeight
        ? 100 : (window.scrollY / (document.body.scrollHeight - window.innerHeight)) * 100;
      fill.style.width = pct + '%';
    });
  }
  function removeProgressBar() {
    document.getElementById('bm-progress')?.remove();
  }

  // ── STREAK ──────────────────────────────────────────────────────
  function updateStreak() {
    if (!S.streakEnabled) return;
    const today = new Date().toDateString();
    const yesterday = new Date(Date.now() - 86400000).toDateString();
    if (S.lastStudyDate === today) return;
    const streak = S.lastStudyDate === yesterday ? (S.currentStreak || 0) + 1 : 1;
    S.currentStreak = streak; S.lastStudyDate = today;
    chrome.storage.sync.set({ currentStreak: streak, lastStudyDate: today });
    refreshSidebar();
    if (streak > 1) toast(`🔥 ${streak}-day streak! Keep it up!`, 'info');
  }

  // ── ANSWER DETECTION ────────────────────────────────────────────
  function watchAnswers() {
    new MutationObserver(() => {
      const el = document.querySelector('[class*="correct"i],[data-correct="true"],[class*="CorrectAnswer"i]');
      if (el) {
        const id = el.textContent.substring(0, 30);
        if (id !== lastAnswerId) {
          lastAnswerId = id;
          onCorrect();
        }
      }
    }).observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['class','data-correct'] });
  }

  function onCorrect() {
    S.totalAnswered  = (S.totalAnswered  || 0) + 1;
    S.totalCorrect   = (S.totalCorrect   || 0) + 1;
    chrome.storage.sync.set({ totalAnswered: S.totalAnswered, totalCorrect: S.totalCorrect });
    awardXP(15);
    if (S.confettiEnabled && S.totalCorrect % 5 === 0) confetti(25);
    if (S.soundEnabled && S.totalCorrect % 3 === 0) chime([659, 784]);
    refreshSidebar();
    checkAchievements();
  }

  // ── XP ──────────────────────────────────────────────────────────
  function awardXP(amt) {
    if (!S.xpEnabled) return;
    const newXP = (S.currentXP || 0) + amt;
    const newLv = Math.floor(newXP / 100) + 1;
    const levelled = newLv > (S.currentLevel || 1);
    S.currentXP = newXP; S.currentLevel = newLv;
    chrome.storage.sync.set({ currentXP: newXP, currentLevel: newLv });
    floatXP(amt);
    if (levelled) {
      toast(`🎉 Level Up! You're now Level ${newLv}`, 'success');
      if (S.confettiEnabled) confetti(60);
      if (S.soundEnabled) chime([523,659,784,1046,1318]);
    }
    refreshSidebar();
    checkAchievements();
  }

  function floatXP(amt) {
    const el = document.createElement('div');
    el.className = 'bm-xp-float';
    el.textContent = `+${amt} XP`;
    el.style.cssText = `right:${50 + Math.random()*60}px; bottom:${60 + Math.random()*40}px;`;
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 1700);
  }

  // ── ACHIEVEMENTS ────────────────────────────────────────────────
  function checkAchievements() {
    const got = S.achievements || [];
    for (const ach of ACHIEVEMENTS) {
      if (!got.includes(ach.id) && ach.check(S)) {
        got.push(ach.id);
        S.achievements = got;
        chrome.storage.sync.set({ achievements: got });
        showAchievement(ach);
        buildAchievements();
      }
    }
  }

  function showAchievement(ach) {
    if (!S.achievementsEnabled) return;
    const el = document.createElement('div');
    el.className = 'bm-achievement';
    el.innerHTML = `
      <div class="bm-ach-icon">${ach.icon}</div>
      <div>
        <div class="bm-ach-tag">Achievement Unlocked</div>
        <div class="bm-ach-name">${ach.name}</div>
        <div class="bm-ach-desc">${ach.desc}</div>
      </div>`;
    document.body.appendChild(el);
    setTimeout(() => el.classList.add('bm-in'), 50);
    if (S.soundEnabled) chime([784, 1046, 1318]);
    setTimeout(() => { el.classList.remove('bm-in'); setTimeout(() => el.remove(), 500); }, 4500);
  }

  // ── HINT GLOW ───────────────────────────────────────────────────
  function watchHints() {
    new MutationObserver(() => {
      if (!S.hintGlow) return;
      document.querySelectorAll('[class*="hint"i],[data-testid*="hint"i]').forEach(el => {
        if (!el.dataset.bmH) { el.dataset.bmH = '1'; el.classList.add('bm-hint-glow'); }
      });
    }).observe(document.body, { childList: true, subtree: true });
  }

  // ── BREAK TIMER ──────────────────────────────────────────────────
  let _breakTimer = null;
  function startBreakTimer() {
    clearBreakTimer();
    _breakTimer = setInterval(() => {
      if (S.breakReminder) toast(`🧘 Break time! You've studied for ${S.breakInterval || 30} mins.`, 'info');
    }, (S.breakInterval || 30) * 60000);
  }
  function clearBreakTimer() {
    if (_breakTimer) clearInterval(_breakTimer);
  }

  // ── QUOTE ────────────────────────────────────────────────────────
  function showQuote() {
    const q = QUOTES[Math.floor(Math.random() * QUOTES.length)];
    const el = document.createElement('div');
    el.className = 'bm-toast';
    el.style.cssText += '; border-left: 3px solid var(--bm-acc, #00C896); max-width: 460px;';
    el.innerHTML = `<span>💡</span><span style="flex:1"><em>"${q.q}"</em><br><span style="font-size:.7rem;opacity:.5;margin-top:3px;display:block">— ${q.a}</span></span><button class="bm-toast-x">×</button>`;
    document.body.appendChild(el);
    el.querySelector('.bm-toast-x').onclick = () => el.remove();
    setTimeout(() => el.classList.add('bm-in'), 80);
    setTimeout(() => { el.classList.remove('bm-in'); setTimeout(() => el.remove(), 400); }, 8000);
  }

  // ── SESSION TRACKING ─────────────────────────────────────────────
  function trackSession() {
    // Update the "mins today" stat every 30s
    setInterval(() => {
      const el = document.getElementById('bm-stat-mins');
      if (el) el.textContent = Math.round((Date.now() - sessionStart) / 60000);
    }, 30000);
    window.addEventListener('beforeunload', () => {
      const mins = Math.round((Date.now() - sessionStart) / 60000);
      if (mins > 0) chrome.storage.sync.set({ totalStudyMins: (S.totalStudyMins || 0) + mins });
    });
  }

  // ── TOAST ────────────────────────────────────────────────────────
  function toast(msg, type = 'info') {
    const colors = { info: 'rgba(0,150,255,0.3)', success: 'rgba(0,200,150,0.3)', error: 'rgba(255,68,68,0.3)', achievement: 'rgba(0,200,150,0.5)' };
    const el = document.createElement('div');
    el.className = 'bm-toast';
    el.style.borderColor = colors[type] || colors.info;
    el.innerHTML = `<span>${msg}</span><button class="bm-toast-x">×</button>`;
    el.querySelector('.bm-toast-x').onclick = () => el.remove();
    document.body.appendChild(el);
    setTimeout(() => el.classList.add('bm-in'), 30);
    setTimeout(() => { el.classList.remove('bm-in'); setTimeout(() => el.remove(), 400); }, 4200);
  }

  // ── CONFETTI ─────────────────────────────────────────────────────
  function confetti(n = 40) {
    const colors = ['#00C896','#F43F5E','#3B82F6','#F59E0B','#8B5CF6','#00FF88'];
    for (let i = 0; i < n; i++) {
      const el = document.createElement('div');
      el.className = 'bm-confetti-piece';
      const drift = (Math.random() - 0.5) * 120;
      el.style.cssText = `
        left:${10 + Math.random()*80}vw;
        background:${colors[i % colors.length]};
        width:${5 + Math.random()*7}px; height:${5 + Math.random()*7}px;
        animation-duration:${1.2 + Math.random()*1.8}s;
        animation-delay:${Math.random()*0.4}s;
        --drift:${drift}px;
        border-radius:${Math.random() > 0.5 ? '50%' : '2px'};
      `;
      document.body.appendChild(el);
      setTimeout(() => el.remove(), 3500);
    }
  }

  // ── CHIME ─────────────────────────────────────────────────────────
  function chime(freqs) {
    try {
      const ctx = new (window.AudioContext || window.webkitAudioContext)();
      freqs.forEach((f, i) => {
        const o = ctx.createOscillator(), g = ctx.createGain();
        o.connect(g); g.connect(ctx.destination);
        o.frequency.value = f; o.type = 'sine';
        g.gain.setValueAtTime(0.22, ctx.currentTime + i*0.13);
        g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + i*0.13 + 0.45);
        o.start(ctx.currentTime + i*0.13);
        o.stop(ctx.currentTime + i*0.13 + 0.45);
      });
    } catch(e) {}
  }

})();

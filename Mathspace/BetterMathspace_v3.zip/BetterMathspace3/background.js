// BetterMathspace v3 — Background Worker

const DEFAULTS = {
  // Sidebar
  sidebarOpen: false,
  sidebarPosition: 'left',

  // Appearance
  darkMode: false,
  theme: 'cyber',
  accentColor: '#00C896',
  customProfilePic: '',
  customBackground: '',
  backgroundOpacity: 12,
  backgroundBlur: 6,
  glassmorphism: true,
  customCSS: '',
  rainbowMode: false,
  animationsEnabled: true,
  smoothScroll: true,
  fontScale: 100,

  // Productivity
  pomodoroWork: 25,
  pomodoroBreak: 5,
  pomodoroLongBreak: 15,
  focusMode: false,
  breakReminder: true,
  breakInterval: 30,
  notesEnabled: true,
  notes: '',

  // Gamification
  xpEnabled: true,
  streakEnabled: true,
  achievementsEnabled: true,
  confettiEnabled: true,
  soundEnabled: false,
  currentXP: 0,
  currentLevel: 1,
  currentStreak: 0,
  lastStudyDate: null,
  totalAnswered: 0,
  totalCorrect: 0,
  achievements: [],
  totalStudyMins: 0,

  // Features
  hintGlow: true,
  progressBar: true,
  questionDetect: true,
  quotesEnabled: true,
  quoteCategory: 'mixed',
  particlesEnabled: false,
  pinnedLinks: [
    { icon: '📈', label: 'Desmos',      url: 'https://www.desmos.com/calculator' },
    { icon: '🔢', label: 'WolframAlpha', url: 'https://www.wolframalpha.com' },
    { icon: '📐', label: 'GeoGebra',    url: 'https://www.geogebra.org' }
  ],

  // Weekly goal
  weeklyGoal: 300,
};

chrome.runtime.onInstalled.addListener(async () => {
  const existing = await chrome.storage.sync.get(null);
  const toSet = {};
  for (const [k, v] of Object.entries(DEFAULTS)) {
    if (!(k in existing)) toSet[k] = v;
  }
  if (Object.keys(toSet).length) await chrome.storage.sync.set(toSet);
});

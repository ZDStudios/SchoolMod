// BetterMathspace v3 — Settings JS
const ACH = [
  { id:'first',    icon:'🌱', name:'First Step',    desc:'Answer 1 question'   },
  { id:'ten',      icon:'🔢', name:'Double Digits', desc:'10 questions'        },
  { id:'fifty',    icon:'🏃', name:'On A Roll',     desc:'50 questions'        },
  { id:'century',  icon:'💯', name:'Century',       desc:'100 questions'       },
  { id:'streak3',  icon:'🔥', name:'On Fire',       desc:'3-day streak'        },
  { id:'streak7',  icon:'⚡', name:'Week Warrior',  desc:'7-day streak'        },
  { id:'streak30', icon:'👑', name:'Unstoppable',   desc:'30-day streak'       },
  { id:'xp100',    icon:'⭐', name:'XP Rookie',     desc:'Earn 100 XP'         },
  { id:'xp500',    icon:'🌟', name:'XP Hunter',     desc:'Earn 500 XP'         },
  { id:'xp1000',   icon:'💎', name:'XP Legend',     desc:'Earn 1000 XP'        },
  { id:'level5',   icon:'🚀', name:'Rising Star',   desc:'Reach Level 5'       },
  { id:'level10',  icon:'🏆', name:'Pro',           desc:'Reach Level 10'      },
  { id:'nightowl', icon:'🦉', name:'Night Owl',     desc:'Study after 9pm'     },
  { id:'earlybird',icon:'🐦', name:'Early Bird',    desc:'Study before 7am'    },
];

let S = {}, dirty = false;

document.addEventListener('DOMContentLoaded', () => {
  chrome.storage.sync.get(null, d => { S = d; populate(); wireNav(); wireAll(); });
});

function wireNav() {
  document.querySelectorAll('.nav-item').forEach(el => {
    el.addEventListener('click', () => {
      document.querySelectorAll('.nav-item').forEach(x => x.classList.remove('on'));
      document.querySelectorAll('.sec').forEach(x => x.classList.remove('on'));
      el.classList.add('on');
      document.getElementById('t-' + el.dataset.t)?.classList.add('on');
    });
  });
}

function populate() {
  // Checkboxes
  ['darkMode','confettiEnabled','progressBar','hintGlow','soundEnabled','focusMode',
   'smoothScroll','breakReminder','notesEnabled','xpEnabled','streakEnabled','achievementsEnabled','quotesEnabled'
  ].forEach(id => { const el = document.getElementById(id); if (el) el.checked = !!S[id]; });

  // Selects
  v('quoteCategory', S.quoteCategory || 'mixed');

  // Numbers
  v('pomodoroWork', S.pomodoroWork || 25);
  v('pomodoroBreak', S.pomodoroBreak || 5);
  v('pomodoroLongBreak', S.pomodoroLongBreak || 15);
  v('pomodoroSessions', S.pomodoroSessions || 4);

  // Text
  v('customBackground', S.customBackground || '');
  v('customCSS', S.customCSS || '');
  v('notesContent', S.notes || '');

  // Ranges
  range('backgroundOpacity', S.backgroundOpacity || 12, 'bgOpVal', '%');
  range('backgroundBlur',    S.backgroundBlur    || 6,  'bgBlurVal', 'px');
  range('breakInterval',     S.breakInterval     || 30, 'breakVal', 'm');
  range('weeklyGoal',        S.weeklyGoal        || 300,'goalVal', 'm');

  // Accent
  v('accentColor', S.accentColor || '#00C896');
  document.querySelectorAll('.swatch').forEach(s => s.classList.toggle('on', s.dataset.c === (S.accentColor || '#00C896')));

  // PFP
  if (S.customProfilePic) showPfp(S.customProfilePic);

  // XP display
  fillXP();

  // Stats
  t('sA', S.totalAnswered  || 0);
  t('sC', S.totalCorrect   || 0);
  t('sX', S.currentXP      || 0);
  t('sS', S.currentStreak  || 0);
  t('sAc', (S.achievements||[]).length);
  t('sM', S.totalStudyMins || 0);
  t('streakNum', S.currentStreak || 0);

  // Achievements
  renderAch();

  // Links
  renderLinks();
}

function fillXP() {
  const xp = S.currentXP || 0;
  const lv = Math.floor(xp/100) + 1;
  const inLv = xp % 100;
  t('lvBadge', `Level ${lv}`);
  t('xpPts', `${inLv} / 100 XP`);
  const fill = document.getElementById('xpFill');
  if (fill) fill.style.width = inLv + '%';
}

function renderAch() {
  const grid = document.getElementById('achGrid');
  if (!grid) return;
  const got = S.achievements || [];
  grid.innerHTML = ACH.map(a => `
    <div class="at${got.includes(a.id) ? ' got' : ''}">
      <div class="at-em">${a.icon}</div>
      <div class="at-nm">${a.name}</div>
      <div class="at-ds">${a.desc}</div>
    </div>`).join('');
}

function renderLinks() {
  const list = document.getElementById('linkList');
  if (!list) return;
  const links = S.pinnedLinks || [];
  list.innerHTML = links.map((l, i) => `
    <div class="lr">
      <input class="li-ico" type="text" value="${esc(l.icon||'🔗')}" data-i="${i}" data-f="icon" placeholder="🔗">
      <input type="text" value="${esc(l.label||'')}" data-i="${i}" data-f="label" placeholder="Label" style="max-width:90px">
      <input type="text" value="${esc(l.url||'')}" data-i="${i}" data-f="url" placeholder="https://...">
      <button class="ldel" data-i="${i}">🗑</button>
    </div>`).join('');
  list.querySelectorAll('input').forEach(inp => {
    inp.addEventListener('input', () => {
      const i = +inp.dataset.i, f = inp.dataset.f;
      if (!S.pinnedLinks) S.pinnedLinks = [];
      if (!S.pinnedLinks[i]) S.pinnedLinks[i] = {};
      S.pinnedLinks[i][f] = inp.value;
      markDirty();
    });
  });
  list.querySelectorAll('.ldel').forEach(btn => {
    btn.addEventListener('click', () => { S.pinnedLinks.splice(+btn.dataset.i, 1); renderLinks(); markDirty(); });
  });
}

function showPfp(src) {
  const ring = document.getElementById('pfpRing');
  const ctrl = document.getElementById('pfpControls');
  const img  = document.getElementById('pfpImg');
  if (ring) ring.innerHTML = `<img src="${src}" style="width:100%;height:100%;object-fit:cover;border-radius:50%">`;
  if (ctrl) ctrl.style.display = 'block';
  if (img) img.src = src;
}

function wireAll() {
  // Checkboxes
  ['darkMode','confettiEnabled','progressBar','hintGlow','soundEnabled','focusMode',
   'smoothScroll','breakReminder','notesEnabled','xpEnabled','streakEnabled','achievementsEnabled','quotesEnabled'
  ].forEach(id => document.getElementById(id)?.addEventListener('change', e => { S[id] = e.target.checked; markDirty(); }));

  // Selects + text
  ['quoteCategory','customBackground','customCSS'].forEach(id =>
    document.getElementById(id)?.addEventListener('input', e => { S[id] = e.target.value; markDirty(); })
  );

  // Numbers
  ['pomodoroWork','pomodoroBreak','pomodoroLongBreak','pomodoroSessions'].forEach(id =>
    document.getElementById(id)?.addEventListener('input', e => { S[id] = +e.target.value; markDirty(); })
  );

  // Accent
  document.getElementById('accentColor')?.addEventListener('input', e => {
    S.accentColor = e.target.value;
    document.querySelectorAll('.swatch').forEach(s => s.classList.remove('on'));
    markDirty();
  });
  document.querySelectorAll('.swatch').forEach(s => s.addEventListener('click', () => {
    document.querySelectorAll('.swatch').forEach(x => x.classList.remove('on'));
    s.classList.add('on');
    S.accentColor = s.dataset.c;
    document.getElementById('accentColor').value = s.dataset.c;
    markDirty();
  }));

  // Ranges
  [['backgroundOpacity','bgOpVal','%'],['backgroundBlur','bgBlurVal','px'],['breakInterval','breakVal','m'],['weeklyGoal','goalVal','m']].forEach(([id,d,sfx]) => {
    document.getElementById(id)?.addEventListener('input', e => {
      S[id] = +e.target.value;
      const el = document.getElementById(d); if (el) el.textContent = e.target.value+sfx;
      markDirty();
    });
  });

  // BG preview
  document.getElementById('bgPreviewBtn')?.addEventListener('click', () => {
    const url = g('customBackground'); const box = document.getElementById('bgPreviewBox');
    if (url && box) { box.style.display='block'; box.style.backgroundImage=`url('${url}')`; }
  });
  document.getElementById('bgClear')?.addEventListener('click', () => {
    S.customBackground=''; v('customBackground','');
    document.getElementById('bgPreviewBox').style.display='none'; markDirty();
  });

  // PFP
  document.getElementById('pfpInput')?.addEventListener('change', e => {
    const file = e.target.files[0];
    if (!file||file.size>2097152) { flash('Image too large',true); return; }
    const r = new FileReader();
    r.onload = ev => { S.customProfilePic=ev.target.result; showPfp(ev.target.result); markDirty(); };
    r.readAsDataURL(file);
  });
  document.getElementById('pfpRemove')?.addEventListener('click', () => {
    S.customProfilePic=''; document.getElementById('pfpRing').innerHTML='🧑';
    document.getElementById('pfpControls').style.display='none'; markDirty();
  });

  // Notes
  document.getElementById('saveNotes')?.addEventListener('click', () => {
    S.notes = g('notesContent'); chrome.storage.sync.set({notes:S.notes}); flash('Notes saved ✓');
  });
  document.getElementById('clearNotes')?.addEventListener('click', () => {
    S.notes=''; v('notesContent',''); chrome.storage.sync.set({notes:''});
  });
  document.getElementById('notesContent')?.addEventListener('input', e => { S.notes=e.target.value; markDirty(); });

  // CSS
  document.getElementById('saveCSS')?.addEventListener('click', () => {
    S.customCSS = g('customCSS'); chrome.storage.sync.set({customCSS:S.customCSS}); flash('CSS saved ✓');
  });
  document.getElementById('clearCSS')?.addEventListener('click', () => {
    S.customCSS=''; v('customCSS',''); chrome.storage.sync.set({customCSS:''});
  });

  // XP reset
  document.getElementById('resetXP')?.addEventListener('click', () => {
    if (!confirm('Reset XP and streak?')) return;
    Object.assign(S, {currentXP:0,currentLevel:1,currentStreak:0,lastStudyDate:null});
    chrome.storage.sync.set({currentXP:0,currentLevel:1,currentStreak:0,lastStudyDate:null});
    fillXP(); t('streakNum',0); flash('Reset.');
  });

  // Stats reset
  document.getElementById('resetAll')?.addEventListener('click', () => {
    if (!confirm('Reset ALL stats permanently?')) return;
    const r={currentXP:0,currentLevel:1,currentStreak:0,lastStudyDate:null,totalAnswered:0,totalCorrect:0,totalStudyMins:0,achievements:[]};
    Object.assign(S,r); chrome.storage.sync.set(r);
    fillXP(); renderAch();
    ['sA','sC','sX','sS','sAc','sM','streakNum'].forEach(id=>t(id,0));
    flash('All stats reset.');
  });

  // Links
  document.getElementById('addLink')?.addEventListener('click', () => {
    if (!S.pinnedLinks) S.pinnedLinks=[];
    S.pinnedLinks.push({icon:'🔗',label:'',url:''}); renderLinks(); markDirty();
  });
  document.querySelectorAll('.sugg-btn').forEach(btn => btn.addEventListener('click', () => {
    if (!S.pinnedLinks) S.pinnedLinks=[];
    S.pinnedLinks.push({icon:btn.dataset.i,label:btn.dataset.l,url:btn.dataset.u});
    renderLinks(); markDirty();
  }));

  // Save bar
  document.getElementById('saveAllBtn')?.addEventListener('click', saveAll);
  document.getElementById('discardBtn')?.addEventListener('click', () => {
    chrome.storage.sync.get(null, d => { S=d; populate(); clearDirty(); });
  });
}

function saveAll() {
  const d = {
    darkMode:gc('darkMode'), confettiEnabled:gc('confettiEnabled'), progressBar:gc('progressBar'),
    hintGlow:gc('hintGlow'), soundEnabled:gc('soundEnabled'), focusMode:gc('focusMode'),
    smoothScroll:gc('smoothScroll'), breakReminder:gc('breakReminder'), notesEnabled:gc('notesEnabled'),
    xpEnabled:gc('xpEnabled'), streakEnabled:gc('streakEnabled'), achievementsEnabled:gc('achievementsEnabled'),
    quotesEnabled:gc('quotesEnabled'),
    quoteCategory:g('quoteCategory'), customBackground:g('customBackground'), customCSS:g('customCSS'),
    notes:g('notesContent'), accentColor:S.accentColor||'#00C896', customProfilePic:S.customProfilePic||'',
    backgroundOpacity:+g('backgroundOpacity'), backgroundBlur:+g('backgroundBlur'),
    breakInterval:+g('breakInterval'), weeklyGoal:+g('weeklyGoal'),
    pomodoroWork:+g('pomodoroWork'), pomodoroBreak:+g('pomodoroBreak'),
    pomodoroLongBreak:+g('pomodoroLongBreak'), pomodoroSessions:+g('pomodoroSessions'),
    pinnedLinks: S.pinnedLinks||[],
  };
  chrome.storage.sync.set(d, () => { Object.assign(S,d); clearDirty(); flash('✅ Saved!'); });
}

function markDirty()  { dirty=true;  document.getElementById('save-bar').classList.add('show'); }
function clearDirty() { dirty=false; document.getElementById('save-bar').classList.remove('show'); }

function v(id,val)  { const el=document.getElementById(id); if(el) el.value=val; }
function g(id)      { return document.getElementById(id)?.value??''; }
function gc(id)     { return !!document.getElementById(id)?.checked; }
function t(id,val)  { const el=document.getElementById(id); if(el) el.textContent=val; }
function esc(s)     { return String(s).replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;'); }
function range(id,val,dId,sfx) { v(id,val); t(dId, val+sfx); }

function flash(msg, err=false) {
  const el=document.createElement('div');
  Object.assign(el.style,{
    position:'fixed',top:'16px',left:'50%',transform:'translateX(-50%) translateY(-60px)',
    background:err?'rgba(239,68,68,.95)':'rgba(0,200,150,.95)',color:err?'#fff':'#000',
    padding:'8px 20px',borderRadius:'22px',fontFamily:"'DM Sans',sans-serif",
    fontWeight:'700',fontSize:'.8rem',zIndex:'99999',
    boxShadow:'0 6px 24px rgba(0,0,0,.5)',transition:'transform .35s cubic-bezier(.34,1.56,.64,1),opacity .35s',opacity:'0'
  });
  el.textContent=msg; document.body.appendChild(el);
  setTimeout(()=>{el.style.transform='translateX(-50%) translateY(0)';el.style.opacity='1';},30);
  setTimeout(()=>{el.style.opacity='0';el.style.transform='translateX(-50%) translateY(-40px)';setTimeout(()=>el.remove(),350);},2200);
}

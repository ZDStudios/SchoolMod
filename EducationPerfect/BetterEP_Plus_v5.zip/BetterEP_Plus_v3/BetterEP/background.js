// BetterEP+ — Background Service Worker v2.0

chrome.runtime.onInstalled.addListener(({ reason }) => {
  if (reason === 'install') {
    chrome.tabs.create({ url: 'https://app.educationperfect.com/' });
  }
  chrome.alarms.create('bep-task-reminder', { periodInMinutes: 60 });
  chrome.contextMenus.create({
    id: 'bep-open', title: 'Open Education Perfect', contexts: ['action'],
  });
});

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name !== 'bep-task-reminder') return;
  const { bepSettings } = await chrome.storage.sync.get('bepSettings');
  if (!bepSettings?.taskNotifications) return;
  chrome.notifications.create({
    type: 'basic',
    iconUrl: 'icons/icon48.png',
    title: '⚡ BetterEP+ Reminder',
    message: "Don't forget to check your Education Perfect tasks!",
    priority: 1,
  });
});

chrome.notifications.onClicked.addListener((id) => {
  if (id.startsWith('bep-')) {
    chrome.tabs.create({ url: 'https://app.educationperfect.com/' });
    chrome.notifications.clear(id);
  }
});

chrome.contextMenus.onClicked.addListener((info) => {
  if (info.menuItemId === 'bep-open') {
    chrome.tabs.create({ url: 'https://app.educationperfect.com/' });
  }
});

// Handle notification requests from content script
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === 'BEP_NOTIFICATION') {
    chrome.notifications.create({
      type: 'basic',
      iconUrl: 'icons/icon48.png',
      title: msg.title || 'BetterEP+',
      message: msg.body || '',
      priority: 2,
    });
  }
});

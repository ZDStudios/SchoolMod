# ⚡ BetterEP+

> The ultimate student-made enhancement suite for Education Perfect.

BetterEP+ supercharges your Education Perfect experience with dark mode, custom themes, a task summary panel, focus timer, custom profile pictures, and much more — all without touching EP's servers.

---

## ✨ Features

### 🎨 Appearance
- **Dark Mode** — A comprehensive dark theme that actually works on EP's React UI, including inline style overrides
- **8 Built-in Themes** — Default, Ocean, Forest, Sunset, Candy, Midnight, Rose, Amber
- **Custom Accent Colour** — Pick any colour to use as the highlight throughout EP
- **Live Wallpapers** — Set any image URL (or MP4 video) as your background with adjustable overlay
- **6 Quick Wallpaper Presets** — Beautiful Unsplash backgrounds built in
- **Custom Font** — Choose from 10 Google Fonts including Geist, Inter, Nunito, Poppins, and more
- **Font Scale** — Make text bigger or smaller (85%–125%)
- **Compact Mode** — Tighter layout for more content on screen
- **Smooth Animations** — Hover effects and card transitions throughout EP

### 👤 Profile
- **Custom Profile Picture** — Override your EP avatar with any image URL
- **Shape Options** — Circle, rounded square, or square

### 📋 Task Summary Panel
A new sidebar panel injected into EP with 4 tabs:

**Summary Tab**
- Personalised greeting with your name
- Daily motivational quote
- Scrapes and lists your current EP tasks
- Colour-coded urgency badges: 🔥 Due Today, ⏰ Due Soon, ✅ On Track
- Shows subject, due date, and progress % per task
- Refresh button to re-scan the page

**Timer Tab (Pomodoro)**
- Built-in focus timer
- Configurable work/break durations
- Session counter
- Browser notification when session ends
- Pulse animation when time is almost up

**Notes Tab**
- Quick notepad that saves automatically to localStorage
- Character counter
- Clear button

**Settings Tab**
- Full settings panel built into the sidebar
- All settings saved and synced in real time — no save button needed

### ⚙️ Settings (Inline)
All settings live inside the EP page sidebar — no need to open the extension popup. Settings are synced via Chrome's storage API.

### 🔔 Notifications & Alerts
- **Points Toast** — Detects when you earn EP points and shows a pop-up
- **Task Reminders** — Optional hourly browser notifications
- **Focus Timer Alerts** — Notified when work/break sessions end

### 🎯 Focus Mode
- Dims EP's nav and header so you can concentrate on the content
- Hover over dimmed elements to restore them temporarily
- Toggle with `Alt+F` or from the Quick Actions bar

### 🛠 Power User
- **Custom CSS** — Inject any CSS you want into EP
- **Hidden Nav Items** — Hide sidebar items you never use
- **Keyboard Shortcuts** — Control everything without touching the mouse

---

## ⌨️ Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| `Alt + D` | Toggle Dark Mode |
| `Alt + F` | Toggle Focus Mode |
| `Alt + P` | Jump to Timer tab |
| `Alt + S` | Jump to Summary tab |

---

## 🚀 Installation

1. Download `BetterEP_Plus.zip` and unzip it
2. Open Chrome and navigate to `chrome://extensions/`
3. Enable **Developer mode** (toggle in the top right)
4. Click **Load unpacked**
5. Select the `BetterEP` folder
6. Navigate to [app.educationperfect.com](https://app.educationperfect.com)
7. The ⚡ BetterEP+ panel will appear on the right side of your screen

---

## 🗂 Project Structure

```
BetterEP/
├── manifest.json          Chrome Extension manifest (v3)
├── content.js             Main orchestrator script
├── betterep.css           All injected styles
├── background.js          Service worker (notifications, alarms)
├── popup.html / popup.js  Extension toolbar popup
└── modules/
    ├── storage.js         Settings API & shared utilities
    ├── dark-mode.js       Comprehensive dark mode engine
    ├── profile-pic.js     Custom avatar override
    ├── sidebar.js         Injected panel & tabs
    ├── summary.js         Task scraping & display
    ├── timer.js           Pomodoro focus timer
    ├── settings-panel.js  In-page settings UI
    └── notifications.js   Points watcher & keyboard shortcuts
```

---

## 📋 Roadmap

- [ ] Mathspace support (BetterMathspace+)
- [ ] Subject colour coding
- [ ] Grade tracker / progress graphs
- [ ] Widget reordering on dashboard
- [ ] Custom sounds for timer
- [ ] Export notes as text file
- [ ] Cloud sync for notes
- [ ] Firefox support

---

## ⚠️ Disclaimer

BetterEP+ is a community-made project by students, for students. It is not affiliated with, endorsed by, or connected to Education Horizons Group or Education Perfect Ltd. Use at your own discretion.

---

## ❤️ Contributing

Pull requests welcome! If you fix a selector for EP's latest update or add a new feature, feel free to open a PR.

---

*Made with ❤️ for students who just want a better experience.*

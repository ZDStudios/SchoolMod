// ════════════════════════════════════════════
//  BetterEP+ v3.0 — Main Content Script
// ════════════════════════════════════════════
const BEP_VERSION = '3.0.0';

let _panelBuilt    = false;
let _timerInited   = false;
let _summaryInited = false;
let _toastShown    = false;

// ── Apply all visual settings ──
function applyVisuals() {
  const s    = BEP.settings;
  const body = document.body;
  if (!body) return;

  body.classList.toggle('bep-active', !!s.enabled);

  if (!s.enabled) {
    ['bep-dark','bep-focus-mode','bep-compact','bep-font-override',
     'bep-font-scale','bep-no-anim'].forEach(c => body.classList.remove(c));
    clearWallpaper();
    document.getElementById('bep-panel')?.remove();
    _panelBuilt = false;
    return;
  }

  // Dark mode
  BEP.darkMode.apply(!!s.darkMode);

  // Theme classes
  const THEMES = ['default','ocean','forest','sunset','candy','midnight','rose','amber'];
  THEMES.forEach(t => body.classList.remove(`bep-theme-${t}`));
  if (s.theme && s.theme !== 'default') body.classList.add(`bep-theme-${s.theme}`);

  // CSS variables
  document.documentElement.style.setProperty('--bep-accent',  s.accentColor  || '#4f8ef7');
  document.documentElement.style.setProperty('--bep-accent2', s.accentColor2 || '#7c5cbf');

  // Modifiers
  body.classList.toggle('bep-focus-mode', !!s.focusMode);
  body.classList.toggle('bep-compact',    !!s.compactMode);
  body.classList.toggle('bep-no-anim',    s.animationsEnabled === false);

  // Font
  if (s.fontOverride && s.fontFamily) {
    body.classList.add('bep-font-override');
    document.documentElement.style.setProperty('--bep-font', `'${s.fontFamily}'`);
    const hasScale = !!(s.fontScale && s.fontScale !== 1);
    body.classList.toggle('bep-font-scale', hasScale);
    if (hasScale) document.documentElement.style.setProperty('--bep-font-scale', s.fontScale);
  } else {
    body.classList.remove('bep-font-override', 'bep-font-scale');
  }

  // Wallpaper — applied directly to body so EP containers can't cover it
  applyWallpaper();

  // Custom CSS
  applyCustomCSS(s.customCSS);

  // Profile pic
  BEP.profilePic.apply();
}

// ── Ensure panel is built (once) ──
function ensurePanel() {
  if (!BEP.settings.enabled) return;
  if (!_panelBuilt) {
    BEP.sidebar.build();
    BEP.settingsPanel.mount();
    _panelBuilt = true;
  } else {
    BEP.settingsPanel.syncValues();
  }
  BEP.sidebar.applyCollapse();
  if (!_summaryInited) { BEP.summary.init(); _summaryInited = true; }
  if (!_timerInited)   { BEP.timer.init();   _timerInited   = true; }
}

function applyAll() {
  applyVisuals();
  ensurePanel();
}

// ── Wallpaper — applied directly to body background ──
function applyWallpaper() {
  const s   = BEP.settings;
  const body = document.body;

  document.documentElement.style.setProperty(
    '--bep-overlay-opacity', String(s.wallpaperOverlay ?? 0.4)
  );

  if (!s.wallpaperUrl) {
    clearWallpaper();
    return;
  }

  if (s.wallpaperType === 'video') {
    // Video: use a fixed overlay div
    clearBodyWallpaper();
    let el = document.getElementById('bep-wallpaper');
    if (!el) {
      el = document.createElement('div');
      el.id = 'bep-wallpaper';
      body.prepend(el);
    }
    const existing = el.querySelector('source');
    if (!existing || existing.getAttribute('src') !== s.wallpaperUrl) {
      el.innerHTML = `<video autoplay muted loop playsinline><source src="${s.wallpaperUrl}"></video>`;
    }
    body.classList.add('bep-wallpaper-active');
  } else {
    // Image: apply directly to body — no container to be covered
    document.getElementById('bep-wallpaper')?.remove();
    body.style.backgroundImage    = `url('${s.wallpaperUrl}')`;
    body.style.backgroundSize     = 'cover';
    body.style.backgroundPosition = 'center';
    body.style.backgroundAttachment = 'fixed';
    body.classList.add('bep-wallpaper-active');

    // Make EP's containers semi-transparent so wallpaper shows through
    injectWallpaperTransparency();
  }
}

function clearBodyWallpaper() {
  const body = document.body;
  body.style.backgroundImage = '';
  body.style.backgroundSize  = '';
  body.style.backgroundPosition = '';
  body.style.backgroundAttachment = '';
  document.getElementById('bep-wallpaper-transparency')?.remove();
}

function clearWallpaper() {
  clearBodyWallpaper();
  document.getElementById('bep-wallpaper')?.remove();
  document.body.classList.remove('bep-wallpaper-active');
}

function injectWallpaperTransparency() {
  // Only inject once
  if (document.getElementById('bep-wallpaper-transparency')) return;
  const style = document.createElement('style');
  style.id = 'bep-wallpaper-transparency';
  // Make EP's top-level layout containers translucent
  style.textContent = `
    body.bep-wallpaper-active > div:not(#bep-panel):not(#bep-toast-container),
    body.bep-wallpaper-active > main:not(#bep-panel),
    body.bep-wallpaper-active #root > div,
    body.bep-wallpaper-active [class*="layout" i]:not(#bep-panel *),
    body.bep-wallpaper-active [class*="Layout" i]:not(#bep-panel *),
    body.bep-wallpaper-active [class*="page" i]:not(#bep-panel *),
    body.bep-wallpaper-active [class*="Page" i]:not(#bep-panel *),
    body.bep-wallpaper-active [class*="app" i]:not(#bep-panel *),
    body.bep-wallpaper-active [class*="App" i]:not(#bep-panel *) {
      background: rgba(255,255,255,calc(1 - var(--bep-overlay-opacity, 0.4))) !important;
    }
    body.bep-dark.bep-wallpaper-active > div:not(#bep-panel):not(#bep-toast-container),
    body.bep-dark.bep-wallpaper-active #root > div,
    body.bep-dark.bep-wallpaper-active [class*="layout" i]:not(#bep-panel *),
    body.bep-dark.bep-wallpaper-active [class*="app" i]:not(#bep-panel *) {
      background: rgba(13,17,23,calc(1 - var(--bep-overlay-opacity, 0.4))) !important;
    }
  `;
  document.head.appendChild(style);
}

// ── Custom CSS ──
function applyCustomCSS(css) {
  let style = document.getElementById('bep-custom-css');
  if (!css) { style?.remove(); return; }
  if (!style) {
    style = document.createElement('style');
    style.id = 'bep-custom-css';
    document.head.appendChild(style);
  }
  if (style.textContent !== css) style.textContent = css;
}

// Settings changed — only re-apply visuals, never rebuild panel
BEP.on('settingsChanged', () => {
  applyVisuals();
  BEP.sidebar.applyCollapse();
});

// Message from popup
try {
  chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
    if (msg.type === 'BEP_SETTINGS_UPDATED') {
      BEP.settings = { ...BEP.DEFAULTS, ...msg.settings };
      applyAll();
      try { reply({ ok: true }); } catch {}
    }
    if (msg.type === 'BEP_PING') {
      try { reply({ version: BEP_VERSION, settings: BEP.settings }); } catch {}
    }
  });
} catch {}

function boot() {
  BEP.notifications.init();
  BEP.profilePic.watch();

  let lastUrl = location.href;
  setInterval(() => {
    if (location.href !== lastUrl) {
      lastUrl = location.href;
      setTimeout(() => {
        applyVisuals();
        BEP.profilePic.apply();
        setTimeout(() => BEP.summary.render(), 2200);
      }, 700);
    }
  }, 500);

  BEP.log(`v${BEP_VERSION} ready ⚡`);
  if (!_toastShown) {
    _toastShown = true;
    setTimeout(() => BEP.toast('⚡ BetterEP+ v3 active', 'info', 2000), 1500);
  }
}

BEP.load(() => {
  const run = () => { applyAll(); boot(); };
  if (document.body) run();
  else document.addEventListener('DOMContentLoaded', run);
});

// BetterEP+ — Popup v2.0
const DEFAULTS = {
  enabled: true, darkMode: false, theme: 'default', accentColor: '#4f8ef7',
  fontFamily: 'Geist', fontOverride: false, compactMode: false, focusMode: false,
};

let settings = { ...DEFAULTS };

const THEME_EMOJI = { default:'✨', ocean:'🌊', forest:'🌿', sunset:'🌅', candy:'🍬', midnight:'🌙', rose:'🌸', amber:'🍯' };

async function load() {
  try {
    const data = await chrome.storage.sync.get('bepSettings');
    if (data.bepSettings) settings = { ...DEFAULTS, ...data.bepSettings };
  } catch {
    try { settings = { ...DEFAULTS, ...JSON.parse(localStorage.getItem('bepSettings')||'{}') }; } catch {}
  }
  render();
}

function render() {
  const s = settings;
  document.getElementById('enabled').checked = !!s.enabled;
  document.body.classList.toggle('dark', s.darkMode);

  // Status
  document.getElementById('status-dot').className = `status-dot ${s.enabled?'':'off'}`;
  document.getElementById('status-text').textContent = s.enabled ? 'Active on Education Perfect' : 'BetterEP+ is disabled';

  // Stats
  document.getElementById('stat-theme').textContent = THEME_EMOJI[s.theme] || '✨';
  document.getElementById('stat-mode').textContent = s.darkMode ? '🌙' : '☀️';
  document.getElementById('stat-font').textContent = s.fontOverride && s.fontFamily ? s.fontFamily.slice(0,2) : 'Aa';

  // Toggle buttons
  document.getElementById('toggle-dark').classList.toggle('active-btn', s.darkMode);
  document.getElementById('dark-label').textContent = s.darkMode ? 'Light Mode' : 'Dark Mode';

  document.getElementById('toggle-focus').classList.toggle('active-btn', s.focusMode);
  document.getElementById('focus-label').textContent = s.focusMode ? 'Focus: ON' : 'Focus Mode';

  document.getElementById('toggle-compact').classList.toggle('active-btn', s.compactMode);
  document.getElementById('compact-label').textContent = s.compactMode ? 'Compact: ON' : 'Compact';
}

async function save(patch) {
  settings = { ...settings, ...patch };
  try { await chrome.storage.sync.set({ bepSettings: settings }); } catch {}
  pushToEP();
  render();
}

function pushToEP() {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const tab = tabs[0];
    if (tab?.url?.includes('educationperfect.com')) {
      chrome.tabs.sendMessage(tab.id, { type: 'BEP_SETTINGS_UPDATED', settings }, () => {});
    }
  });
}

document.addEventListener('DOMContentLoaded', () => {
  load();

  document.getElementById('enabled').addEventListener('change', (e) => save({ enabled: e.target.checked }));
  document.getElementById('toggle-dark').addEventListener('click', () => save({ darkMode: !settings.darkMode }));
  document.getElementById('toggle-focus').addEventListener('click', () => save({ focusMode: !settings.focusMode }));
  document.getElementById('toggle-compact').addEventListener('click', () => save({ compactMode: !settings.compactMode }));

  document.getElementById('open-ep-btn').addEventListener('click', () => {
    chrome.tabs.create({ url: 'https://app.educationperfect.com/' });
  });

  document.getElementById('open-settings').addEventListener('click', () => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const tab = tabs[0];
      if (tab?.url?.includes('educationperfect.com')) {
        chrome.tabs.sendMessage(tab.id, { type: 'BEP_OPEN_SETTINGS' }, () => {});
        window.close();
      } else {
        chrome.tabs.create({ url: 'https://app.educationperfect.com/' });
      }
    });
  });

  document.getElementById('reset-link').addEventListener('click', (e) => {
    e.preventDefault();
    if (confirm('Reset all BetterEP+ settings?')) {
      save({ ...DEFAULTS });
    }
  });
});

// modules/notifications.js — BetterEP+ Points & Task Notifications
window.BEP = window.BEP || {};

BEP.notifications = (() => {
  let lastPoints = null;

  function watchPoints() {
    if (!BEP.settings.showPointsToast) return;
    setInterval(() => {
      const el = document.querySelector(
        '[class*="points" i], [class*="Points"], [aria-label*="points" i], [data-testid*="points"]'
      );
      if (!el) return;
      const pts = parseInt(el.textContent.replace(/[^0-9]/g, ''));
      if (isNaN(pts)) return;
      if (lastPoints !== null && pts > lastPoints) {
        BEP.toast(`⭐ +${pts - lastPoints} points earned!`, 'success');
      }
      lastPoints = pts;
    }, 4000);
  }

  function watchKeyboard() {
    document.addEventListener('keydown', (e) => {
      if (!e.altKey) return;
      switch (e.key.toLowerCase()) {
        case 'd':
          BEP.save({ darkMode: !BEP.settings.darkMode });
          BEP.emit('settingsChanged', BEP.settings);
          BEP.toast(BEP.settings.darkMode ? '🌙 Dark mode on' : '☀️ Light mode on', 'info');
          break;
        case 'f':
          BEP.save({ focusMode: !BEP.settings.focusMode });
          BEP.emit('settingsChanged', BEP.settings);
          BEP.toast(BEP.settings.focusMode ? '🎯 Focus mode on' : '🎯 Focus mode off', 'info');
          break;
        case 'p':
          BEP.sidebar?.switchTab('timer');
          break;
        case 's':
          BEP.sidebar?.switchTab('summary');
          break;
      }
    });
  }

  function init() {
    watchPoints();
    watchKeyboard();
  }

  return { init };
})();

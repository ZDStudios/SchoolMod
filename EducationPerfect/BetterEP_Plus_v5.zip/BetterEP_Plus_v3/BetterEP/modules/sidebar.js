// modules/sidebar.js — BetterEP+ Injected Sidebar Panel
window.BEP = window.BEP || {};

BEP.sidebar = (() => {
  let panel = null;
  let activeTab = 'summary';

  const TABS = [
    { id: 'summary',   icon: '📋', label: 'Summary'   },
    { id: 'timer',     icon: '⏱',  label: 'Timer'     },
    { id: 'notes',     icon: '📝',  label: 'Notes'     },
    { id: 'settings',  icon: '⚙️',  label: 'Settings'  },
  ];

  function build() {
    if (document.getElementById('bep-panel')) return;

    panel = document.createElement('div');
    panel.id = 'bep-panel';
    panel.innerHTML = `
      <div id="bep-panel-inner">
        <!-- Logo bar -->
        <div id="bep-panel-logo">
          <span class="bep-logo-icon">⚡</span>
          <span class="bep-logo-text">BetterEP<span class="bep-logo-plus">+</span></span>
          <button id="bep-panel-close" title="Collapse panel">‹</button>
        </div>

        <!-- Tab strip -->
        <div id="bep-tab-strip">
          ${TABS.map(t => `
            <button class="bep-tab-btn ${t.id === activeTab ? 'active' : ''}" data-tab="${t.id}" title="${t.label}">
              <span class="bep-tab-icon">${t.icon}</span>
              <span class="bep-tab-label">${t.label}</span>
            </button>
          `).join('')}
        </div>

        <!-- Tab content -->
        <div id="bep-tab-content">
          <!-- Summary -->
          <div class="bep-pane ${activeTab === 'summary' ? 'active' : ''}" id="bep-pane-summary">
            <div class="bep-pane-header">Today's Overview</div>
            <div id="bep-summary-body">
              <div class="bep-loading">
                <div class="bep-spinner"></div>
                <span>Loading tasks…</span>
              </div>
            </div>
          </div>

          <!-- Timer -->
          <div class="bep-pane ${activeTab === 'timer' ? 'active' : ''}" id="bep-pane-timer">
            <div class="bep-pane-header">Focus Timer</div>
            <div id="bep-timer-body">
              <div class="bep-timer-display" id="bep-timer-display">25:00</div>
              <div class="bep-timer-mode" id="bep-timer-mode">🎯 Focus</div>
              <div class="bep-timer-controls">
                <button class="bep-btn-round" id="bep-timer-start">▶</button>
                <button class="bep-btn-round bep-btn-secondary" id="bep-timer-reset">↺</button>
              </div>
              <div class="bep-timer-sessions">
                <span id="bep-sessions-count">0</span> sessions today
              </div>
              <div class="bep-timer-config">
                <div class="bep-timer-cfg-row">
                  <span>Work</span>
                  <input type="number" id="bep-cfg-work" min="1" max="60" value="25">
                  <span>min</span>
                </div>
                <div class="bep-timer-cfg-row">
                  <span>Break</span>
                  <input type="number" id="bep-cfg-break" min="1" max="30" value="5">
                  <span>min</span>
                </div>
              </div>
            </div>
          </div>

          <!-- Notes -->
          <div class="bep-pane ${activeTab === 'notes' ? 'active' : ''}" id="bep-pane-notes">
            <div class="bep-pane-header">Quick Notes</div>
            <div id="bep-notes-body">
              <textarea id="bep-notes-area" placeholder="Jot something down…&#10;&#10;Your notes are saved automatically."></textarea>
              <div class="bep-notes-footer">
                <span id="bep-notes-chars">0 chars</span>
                <button class="bep-pill-btn" id="bep-notes-clear">Clear</button>
              </div>
            </div>
          </div>

          <!-- Settings -->
          <div class="bep-pane ${activeTab === 'settings' ? 'active' : ''}" id="bep-pane-settings">
            <div class="bep-pane-header">Quick Settings</div>
            <div id="bep-settings-body">
              <!-- populated by settings-panel.js -->
            </div>
          </div>
        </div>
      </div>

      <!-- Collapsed icon strip -->
      <div id="bep-panel-collapsed">
        <span class="bep-logo-icon">⚡</span>
        ${TABS.map(t => `<button class="bep-col-btn" data-tab="${t.id}" title="${t.label}">${t.icon}</button>`).join('')}
      </div>
    `;

    document.body.appendChild(panel);
    initEvents();
    BEP.log('Sidebar panel injected');
  }

  function initEvents() {
    // Tab switching
    panel.querySelectorAll('.bep-tab-btn, .bep-col-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const tab = btn.dataset.tab;
        switchTab(tab);
        if (panel.classList.contains('collapsed')) expand();
      });
    });

    // Collapse toggle
    document.getElementById('bep-panel-close').addEventListener('click', () => {
      panel.classList.add('collapsed');
      BEP.save({ sidebarCollapsed: true });
    });

    panel.querySelector('#bep-panel-collapsed .bep-logo-icon').addEventListener('click', expand);

    // Notes autosave
    const notesArea = document.getElementById('bep-notes-area');
    if (notesArea) {
      try {
        notesArea.value = localStorage.getItem('bep-notes') || '';
        updateNotesChars(notesArea.value);
      } catch {}
      notesArea.addEventListener('input', () => {
        try { localStorage.setItem('bep-notes', notesArea.value); } catch {}
        updateNotesChars(notesArea.value);
      });
    }

    document.getElementById('bep-notes-clear').addEventListener('click', () => {
      if (confirm('Clear notes?')) {
        notesArea.value = '';
        try { localStorage.removeItem('bep-notes'); } catch {}
        updateNotesChars('');
      }
    });

    // Timer config
    const cfgWork = document.getElementById('bep-cfg-work');
    const cfgBreak = document.getElementById('bep-cfg-break');
    if (cfgWork) cfgWork.value = BEP.settings.timerWork || 25;
    if (cfgBreak) cfgBreak.value = BEP.settings.timerBreak || 5;

    cfgWork?.addEventListener('change', () => {
      BEP.save({ timerWork: parseInt(cfgWork.value) });
      if (!BEP.timer?.isRunning?.()) BEP.timer?.reset?.();
    });
    cfgBreak?.addEventListener('change', () => {
      BEP.save({ timerBreak: parseInt(cfgBreak.value) });
    });
  }

  function updateNotesChars(text) {
    const el = document.getElementById('bep-notes-chars');
    if (el) el.textContent = `${text.length} chars`;
  }

  function switchTab(tab) {
    activeTab = tab;
    panel.querySelectorAll('.bep-tab-btn').forEach(b => b.classList.toggle('active', b.dataset.tab === tab));
    panel.querySelectorAll('.bep-pane').forEach(p => p.classList.toggle('active', p.id === `bep-pane-${tab}`));
  }

  function expand() {
    panel.classList.remove('collapsed');
    BEP.save({ sidebarCollapsed: false });
  }

  function applyCollapse() {
    if (BEP.settings.sidebarCollapsed) panel?.classList.add('collapsed');
    else panel?.classList.remove('collapsed');
  }

  function remove() {
    panel?.remove();
    panel = null;
  }

  // Public
  return { build, remove, switchTab, applyCollapse };
})();

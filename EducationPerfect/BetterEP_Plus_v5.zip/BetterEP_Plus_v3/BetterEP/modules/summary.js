// modules/summary.js — BetterEP+ Task Summary
window.BEP = window.BEP || {};

BEP.summary = (() => {
  let _inited  = false;
  let _lastUrl = '';

  const QUOTES = [
    "The secret of getting ahead is getting started. 🚀",
    "Small progress is still progress. 💪",
    "You've got this. One task at a time. ✅",
    "Work hard in silence, let your grades speak. 📚",
    "Every expert was once a beginner. 🌱",
    "Done is better than perfect. ⚡",
    "Focus on the step in front of you. 🎯",
    "Your only limit is you. 🌟",
    "Great things never came from comfort zones. 🔥",
    "Believe you can and you're halfway there. 💡",
  ];

  function getQuote() {
    return QUOTES[new Date().getDay() % QUOTES.length];
  }

  function scrapeTasksFromDOM() {
    const tasks = [];
    const seen  = new Set();

    const selectors = [
      '[class*="task" i]', '[class*="activity" i]',
      '[class*="assignment" i]', '[class*="homework" i]',
      '[class*="quiz" i]', '[class*="test" i]',
      '[class*="exercise" i]', '[class*="lesson" i]',
    ];

    selectors.forEach(sel => {
      try {
        document.querySelectorAll(sel).forEach(el => {
          if (el.closest('#bep-panel')) return;
          const text = el.innerText?.trim()?.replace(/\s+/g, ' ');
          if (!text || text.length < 6 || text.length > 180) return;
          if (seen.has(text)) return;
          seen.add(text);

          const dueSel    = el.querySelector('[class*="due" i], time, [datetime]');
          const subjectEl = el.querySelector('[class*="subject" i], [class*="course" i], [class*="class" i]');
          const progressEl = el.querySelector('[aria-valuenow], [class*="progress" i] > *');

          const dueText  = dueSel?.getAttribute('datetime') || dueSel?.textContent?.trim() || '';
          const subject  = subjectEl?.textContent?.trim() || '';
          const progress = progressEl?.getAttribute('aria-valuenow')
            || progressEl?.style?.width?.replace('%','')
            || null;

          tasks.push({ text, dueText, subject, progress });
        });
      } catch {}
    });

    return tasks.slice(0, 12);
  }

  function getDueUrgency(dueText) {
    if (!dueText) return 'none';
    const lower = dueText.toLowerCase();
    if (lower.includes('overdue')) return 'overdue';
    if (lower.includes('today') || lower.includes('now')) return 'urgent';
    if (lower.includes('tomorrow') || lower.includes('1 day') || lower.includes('soon')) return 'soon';
    const date = new Date(dueText);
    if (!isNaN(date.getTime())) {
      const days = (date - Date.now()) / 86400000;
      if (days < 0)  return 'overdue';
      if (days < 1)  return 'urgent';
      if (days < 3)  return 'soon';
      return 'ok';
    }
    return 'none';
  }

  const URGENCY_MAP = {
    overdue: ['⚠️ Overdue',  'bep-urgent'],
    urgent:  ['🔥 Due Today','bep-urgent'],
    soon:    ['⏰ Due Soon',  'bep-soon'],
    ok:      ['✅ On Track', 'bep-ok'],
    none:    ['', ''],
  };

  function render() {
    const container = document.getElementById('bep-summary-body');
    if (!container) return;

    const tasks = scrapeTasksFromDOM();
    const now   = new Date();
    const hour  = now.getHours();
    const greeting = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening';

    const nameEl = document.querySelector(
      '[class*="firstName" i], [class*="userName" i], [class*="displayName" i], [class*="fullName" i]'
    );
    const firstName = nameEl?.textContent?.trim()?.split(' ')[0] || '';

    const dateStr = now.toLocaleDateString('en-AU', {
      weekday: 'long', day: 'numeric', month: 'long',
    });

    const taskRows = tasks.length === 0
      ? `<div class="bep-empty-state">
           <div class="bep-empty-icon">🎉</div>
           <div>No tasks detected on this page.</div>
           <div class="bep-empty-sub">Navigate to your learning page and hit refresh.</div>
         </div>`
      : `<div class="bep-task-count">${tasks.length} task${tasks.length !== 1 ? 's' : ''} found</div>
         <div class="bep-task-list">${tasks.map(t => {
           const urgency          = getDueUrgency(t.dueText);
           const [label, urgCls]  = URGENCY_MAP[urgency] || ['', ''];
           return `
             <div class="bep-task-item ${urgCls}">
               <div class="bep-task-name">${t.text.length > 70 ? t.text.slice(0,70) + '…' : t.text}</div>
               ${t.subject ? `<div class="bep-task-subject">${t.subject}</div>` : ''}
               <div class="bep-task-meta">
                 ${label ? `<span class="bep-urgency-tag ${urgCls}">${label}</span>` : ''}
                 ${t.dueText ? `<span class="bep-due-text">${t.dueText}</span>` : ''}
                 ${t.progress !== null ? `
                   <div class="bep-mini-progress"><div class="bep-mini-bar" style="width:${t.progress}%"></div></div>
                   <span class="bep-progress-pct">${t.progress}%</span>
                 ` : ''}
               </div>
             </div>
           `;
         }).join('')}</div>`;

    container.innerHTML = `
      <div class="bep-summary-greeting">${greeting}${firstName ? `, ${firstName}` : ''}! 👋</div>
      ${BEP.settings.motivationalQuotes !== false ? `<div class="bep-summary-quote">${getQuote()}</div>` : ''}
      <div class="bep-summary-date">${dateStr}</div>
      ${taskRows}
      <button class="bep-refresh-btn" id="bep-refresh-summary">↻ Refresh</button>
    `;

    document.getElementById('bep-refresh-summary')?.addEventListener('click', () => {
      container.innerHTML = '<div class="bep-loading"><div class="bep-spinner"></div><span>Refreshing…</span></div>';
      setTimeout(render, 700);
    });
  }

  function init() {
    if (_inited) return;
    _inited = true;

    // First render delayed to let EP paint its content
    setTimeout(render, 2500);
  }

  return { init, render };
})();

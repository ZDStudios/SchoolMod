// modules/dark-mode.js — BetterEP+ Dark Mode Engine v3
// Key fix: every rule excludes #bep-panel and its children
window.BEP = window.BEP || {};

BEP.darkMode = (() => {
  let styleEl = null;
  let observerActive = false;

  const DARK_CSS = `
/* ═══════════════════════════════════════════════════════
   BetterEP+ Dark Mode Engine — excludes #bep-panel fully
   ═══════════════════════════════════════════════════════ */

body.bep-dark { color-scheme: dark; }

/* ── Backgrounds ── */
body.bep-dark *:not(#bep-panel):not(#bep-panel *):not(#bep-toast-container):not(#bep-toast-container *):not(#bep-wallpaper):not(#bep-wallpaper *) {
  background-color: #0d1117 !important;
  border-color: #30363d !important;
}

/* ── Slightly elevated surfaces ── */
body.bep-dark [class*="card" i]:not(#bep-panel *),
body.bep-dark [class*="modal" i]:not(#bep-panel *),
body.bep-dark [class*="dialog" i]:not(#bep-panel *),
body.bep-dark [class*="dropdown" i]:not(#bep-panel *),
body.bep-dark [class*="popover" i]:not(#bep-panel *),
body.bep-dark [class*="menu" i]:not(#bep-panel *),
body.bep-dark [class*="sidebar" i]:not(#bep-panel):not(#bep-panel *),
body.bep-dark [class*="nav" i]:not(#bep-panel *),
body.bep-dark [class*="header" i]:not(#bep-panel *),
body.bep-dark [class*="toolbar" i]:not(#bep-panel *),
body.bep-dark [class*="panel" i]:not(#bep-panel):not(#bep-panel *),
body.bep-dark [class*="container" i]:not(#bep-panel *),
body.bep-dark [class*="wrapper" i]:not(#bep-panel *),
body.bep-dark [class*="content" i]:not(#bep-panel *),
body.bep-dark [class*="layout" i]:not(#bep-panel *),
body.bep-dark [class*="page" i]:not(#bep-panel *),
body.bep-dark [class*="section" i]:not(#bep-panel *),
body.bep-dark [class*="item" i]:not(#bep-panel *),
body.bep-dark [class*="tile" i]:not(#bep-panel *),
body.bep-dark [class*="block" i]:not(#bep-panel *),
body.bep-dark [class*="box" i]:not(#bep-panel *),
body.bep-dark [class*="module" i]:not(#bep-panel *),
body.bep-dark [class*="widget" i]:not(#bep-panel *),
body.bep-dark [class*="activity" i]:not(#bep-panel *),
body.bep-dark [class*="task" i]:not(#bep-panel *),
body.bep-dark [class*="assignment" i]:not(#bep-panel *),
body.bep-dark [class*="course" i]:not(#bep-panel *),
body.bep-dark [class*="lesson" i]:not(#bep-panel *),
body.bep-dark nav:not(#bep-panel *),
body.bep-dark header:not(#bep-panel *),
body.bep-dark aside:not(#bep-panel *),
body.bep-dark main:not(#bep-panel *),
body.bep-dark section:not(#bep-panel *),
body.bep-dark article:not(#bep-panel *),
body.bep-dark footer:not(#bep-panel *),
body.bep-dark [role="dialog"]:not(#bep-panel *),
body.bep-dark [role="navigation"]:not(#bep-panel *),
body.bep-dark [role="main"]:not(#bep-panel *),
body.bep-dark [role="banner"]:not(#bep-panel *),
body.bep-dark [role="complementary"]:not(#bep-panel *) {
  background-color: #161b22 !important;
  border-color: #30363d !important;
}

/* ── Text ── */
body.bep-dark h1:not(#bep-panel *), body.bep-dark h2:not(#bep-panel *),
body.bep-dark h3:not(#bep-panel *), body.bep-dark h4:not(#bep-panel *),
body.bep-dark h5:not(#bep-panel *), body.bep-dark h6:not(#bep-panel *),
body.bep-dark p:not(#bep-panel *),  body.bep-dark span:not(#bep-panel *),
body.bep-dark label:not(#bep-panel *), body.bep-dark li:not(#bep-panel *),
body.bep-dark td:not(#bep-panel *),  body.bep-dark th:not(#bep-panel *),
body.bep-dark strong:not(#bep-panel *), body.bep-dark em:not(#bep-panel *),
body.bep-dark small:not(#bep-panel *), body.bep-dark time:not(#bep-panel *),
body.bep-dark div:not(#bep-panel):not(#bep-panel *) {
  color: #e6edf3 !important;
}

/* ── Muted text ── */
body.bep-dark [class*="muted" i]:not(#bep-panel *),
body.bep-dark [class*="secondary" i]:not(#bep-panel *),
body.bep-dark [class*="hint" i]:not(#bep-panel *),
body.bep-dark [class*="helper" i]:not(#bep-panel *),
body.bep-dark [class*="caption" i]:not(#bep-panel *) {
  color: #8b949e !important;
}

/* ── Inputs ── */
body.bep-dark input:not([type="range"]):not([type="color"]):not([type="checkbox"]):not([type="radio"]):not(#bep-panel *),
body.bep-dark textarea:not(#bep-panel *),
body.bep-dark select:not(#bep-panel *) {
  background-color: #21272e !important;
  border-color: #30363d !important;
  color: #e6edf3 !important;
}
body.bep-dark input:not(#bep-panel *)::placeholder,
body.bep-dark textarea:not(#bep-panel *)::placeholder { color: #6e7681 !important; }

/* ── Inline style overrides ── */
body.bep-dark [style*="background: rgb(255"]:not(#bep-panel *),
body.bep-dark [style*="background: white"]:not(#bep-panel *),
body.bep-dark [style*="background: #fff"]:not(#bep-panel *),
body.bep-dark [style*="background-color: white"]:not(#bep-panel *),
body.bep-dark [style*="background-color: #fff"]:not(#bep-panel *),
body.bep-dark [style*="background-color: #ffffff"]:not(#bep-panel *),
body.bep-dark [style*="background-color: rgb(255, 255, 255)"]:not(#bep-panel *),
body.bep-dark [style*="background-color: rgb(248"]:not(#bep-panel *),
body.bep-dark [style*="background-color: rgb(249"]:not(#bep-panel *),
body.bep-dark [style*="background-color: rgb(250"]:not(#bep-panel *) {
  background-color: #1c2128 !important;
}
body.bep-dark [style*="color: black"]:not(#bep-panel *),
body.bep-dark [style*="color: #000"]:not(#bep-panel *),
body.bep-dark [style*="color: rgb(0, 0, 0)"]:not(#bep-panel *) {
  color: #e6edf3 !important;
}

/* ── Tables ── */
body.bep-dark tr:nth-child(even):not(#bep-panel *) { background-color: #21272e !important; }
body.bep-dark tr:hover:not(#bep-panel *)            { background-color: #2d333b !important; }
body.bep-dark thead:not(#bep-panel *), body.bep-dark th:not(#bep-panel *) {
  background-color: #161b22 !important;
  border-bottom: 1px solid #30363d !important;
}

/* ── HR ── */
body.bep-dark hr:not(#bep-panel *) { border-color: #30363d !important; }

/* ── Scrollbar (not inside panel) ── */
body.bep-dark *:not(#bep-panel *)::-webkit-scrollbar       { width: 6px; height: 6px; }
body.bep-dark *:not(#bep-panel *)::-webkit-scrollbar-track { background: #0d1117; }
body.bep-dark *:not(#bep-panel *)::-webkit-scrollbar-thumb { background: #30363d; border-radius: 3px; }
body.bep-dark *:not(#bep-panel *)::-webkit-scrollbar-thumb:hover { background: var(--bep-accent,#4f8ef7); }

/* ── Buttons ── */
body.bep-dark button:not([class*="primary" i]):not([class*="bep"]):not(#bep-panel *) {
  background-color: #21272e !important;
  border-color: #30363d !important;
  color: #e6edf3 !important;
}

/* ── Code ── */
body.bep-dark code:not(#bep-panel *), body.bep-dark pre:not(#bep-panel *) {
  background-color: #2d333b !important;
  color: #e6edf3 !important;
}

/* ── Images ── */
body.bep-dark img:not(#bep-panel *) { filter: brightness(0.88) saturate(0.92); }
`;

  function inject() {
    if (styleEl) return;
    styleEl = document.createElement('style');
    styleEl.id = 'bep-darkmode-style';
    (document.head || document.documentElement).appendChild(styleEl);
    styleEl.textContent = DARK_CSS;
  }

  function remove() { styleEl?.remove(); styleEl = null; }

  function startObserver() {
    if (observerActive) return;
    observerActive = true;
    const obs = new MutationObserver((muts) => {
      if (!BEP.settings.darkMode) { obs.disconnect(); observerActive = false; return; }
      muts.forEach((m) => {
        const el = m.target;
        if (!el || !el.style || el.id === 'bep-panel' || el.closest?.('#bep-panel')) return;
        if (m.type === 'attributes' && m.attributeName === 'style') {
          const bg = el.style.backgroundColor;
          if (bg && (bg === 'white' || bg === '#fff' || bg === '#ffffff' ||
              bg.startsWith('rgb(255') || bg.startsWith('rgb(248') || bg.startsWith('rgb(249'))) {
            el.style.setProperty('background-color', '#1c2128', 'important');
          }
          const col = el.style.color;
          if (col && (col === 'black' || col === '#000' || col === 'rgb(0, 0, 0)')) {
            el.style.setProperty('color', '#e6edf3', 'important');
          }
        }
      });
    });
    obs.observe(document.documentElement, { attributes: true, attributeFilter: ['style'], subtree: true });
  }

  function apply(enabled) {
    const run = () => {
      document.body?.classList.toggle('bep-dark', enabled);
      if (enabled) { inject(); startObserver(); }
      else remove();
    };
    if (document.body) run();
    else document.addEventListener('DOMContentLoaded', run, { once: true });
  }

  return { apply };
})();

// modules/profile-pic.js — BetterEP+ v3.0 Profile Picture
// Covers: sidebar bottom, leaderboard initials, task header,
//         profile page, navbar icon, any circular avatar EP renders
window.BEP = window.BEP || {};

BEP.profilePic = (() => {
  let _observer  = null;
  let _styleEl   = null;

  // Radius lookup
  function radius(shape) {
    if (shape === 'rounded') return '10px';
    if (shape === 'square')  return '2px';
    return '50%';
  }

  // Inject a CSS rule that overrides EP's own avatar rendering via CSS.
  // This catches elements even before JS queries them.
  function injectCSS(url, shape) {
    const r = radius(shape || 'circle');
    if (!_styleEl) {
      _styleEl = document.createElement('style');
      _styleEl.id = 'bep-profilepic-style';
      document.head?.appendChild(_styleEl);
    }

    if (!url) {
      _styleEl.textContent = '';
      return;
    }

    // EP renders avatars as:
    //   - <img class="...avatar..."> with a src
    //   - <div class="...avatar..."> with background-image
    //   - <div class="...user..."> with a child img or bg-img
    //   - Initials circles: <div> with colored bg and text initials — we override bg-img
    const sel = [
      '[class*="avatar"    i]:not(#bep-panel):not(#bep-panel *)',
      '[class*="Avatar"       ]:not(#bep-panel):not(#bep-panel *)',
      '[class*="profilePic" i]:not(#bep-panel):not(#bep-panel *)',
      '[class*="profileImg" i]:not(#bep-panel):not(#bep-panel *)',
      '[class*="userPhoto"  i]:not(#bep-panel):not(#bep-panel *)',
      '[class*="userImage"  i]:not(#bep-panel):not(#bep-panel *)',
      '[class*="userAvatar" i]:not(#bep-panel):not(#bep-panel *)',
      '[class*="user-icon"  i]:not(#bep-panel):not(#bep-panel *)',
      '[class*="accountIcon"i]:not(#bep-panel):not(#bep-panel *)',
      '[data-testid*="avatar" i]:not(#bep-panel *)',
      '[aria-label*="profile" i]:not(#bep-panel *)',
    ].join(',\n');

    _styleEl.textContent = `
      ${sel} {
        background-image: url('${url}') !important;
        background-size: cover !important;
        background-position: center !important;
        background-repeat: no-repeat !important;
        border-radius: ${r} !important;
        overflow: hidden !important;
        color: transparent !important; /* hide initials */
        font-size: 0 !important;
      }
      /* For <img> avatars */
      img[class*="avatar" i]:not(#bep-panel *),
      img[class*="profilePic" i]:not(#bep-panel *),
      img[class*="userPhoto" i]:not(#bep-panel *),
      img[data-testid*="avatar" i]:not(#bep-panel *) {
        object-fit: cover !important;
        border-radius: ${r} !important;
      }
    `;
  }

  // JS patching for elements we can find right now
  function patchDOM(url, shape) {
    const r = radius(shape || 'circle');
    const selectors = [
      '[class*="avatar"     i]',
      '[class*="Avatar"        ]',
      '[class*="profilePic" i]',
      '[class*="profileImg" i]',
      '[class*="userPhoto"  i]',
      '[class*="userImage"  i]',
      '[class*="userAvatar" i]',
      '[class*="user-icon"  i]',
      '[class*="accountIcon" i]',
      '[data-testid*="avatar" i]',
      '[aria-label*="profile" i]',
    ];

    selectors.forEach(sel => {
      try {
        document.querySelectorAll(`${sel}:not(#bep-panel):not(#bep-panel *)`).forEach(el => {
          // Skip: clearly not a user avatar (too big, or is a flag/subject icon)
          if (el.closest('#bep-panel')) return;
          const rect = el.getBoundingClientRect();
          if (rect.width > 0 && rect.width > 100) return; // skip banners
          if (rect.width > 0 && rect.width < 14) return;  // skip tiny icons

          if (!url) {
            // Restore
            if (el._bepOrigSrc   !== undefined) { el.src = el._bepOrigSrc; delete el._bepOrigSrc; }
            if (el._bepOrigBg    !== undefined) { el.style.backgroundImage = el._bepOrigBg; delete el._bepOrigBg; }
            if (el._bepOrigColor !== undefined) { el.style.color = el._bepOrigColor; delete el._bepOrigColor; }
            el.style.borderRadius = '';
            el.removeAttribute('data-bep-pfp');
          } else {
            if (el.tagName === 'IMG') {
              if (el._bepOrigSrc === undefined) el._bepOrigSrc = el.src;
              el.src = url;
            } else {
              if (el._bepOrigBg    === undefined) el._bepOrigBg    = el.style.backgroundImage;
              if (el._bepOrigColor === undefined) el._bepOrigColor = el.style.color;
              el.style.setProperty('background-image',    `url('${url}')`, 'important');
              el.style.setProperty('background-size',     'cover',         'important');
              el.style.setProperty('background-position', 'center',        'important');
              el.style.setProperty('color',               'transparent',   'important');
            }
            el.style.setProperty('border-radius', r, 'important');
            el.setAttribute('data-bep-pfp', '1');
          }
        });
      } catch {}
    });
  }

  function apply() {
    const { profilePicUrl, profilePicShape } = BEP.settings;
    injectCSS(profilePicUrl, profilePicShape);
    patchDOM(profilePicUrl,  profilePicShape);
  }

  function watch() {
    if (_observer) return;
    _observer = new MutationObserver(() => {
      if (BEP.settings.profilePicUrl) {
        // Throttle to avoid spamming on big renders
        clearTimeout(_observer._t);
        _observer._t = setTimeout(apply, 300);
      }
    });
    _observer.observe(document.body, { childList: true, subtree: true });
  }

  return { apply, watch };
})();

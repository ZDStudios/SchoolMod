// modules/timer.js — BetterEP+ Pomodoro Focus Timer
window.BEP = window.BEP || {};

BEP.timer = (() => {
  let _inited   = false;
  let _interval = null;
  let _seconds  = 0;
  let _isBreak  = false;
  let _sessions = 0;
  let _running  = false;

  const workSecs  = () => (BEP.settings.timerWork  || 25) * 60;
  const breakSecs = () => (BEP.settings.timerBreak || 5)  * 60;

  function fmt(s) {
    return `${String(Math.floor(s / 60)).padStart(2,'0')}:${String(s % 60).padStart(2,'0')}`;
  }

  function updateDisplay() {
    const disp = document.getElementById('bep-timer-display');
    const mode = document.getElementById('bep-timer-mode');
    const btn  = document.getElementById('bep-timer-start');
    const sc   = document.getElementById('bep-sessions-count');

    if (disp) disp.textContent = fmt(_seconds);
    if (mode) mode.textContent = _isBreak ? '☕ Break Time' : '🎯 Focus';
    if (btn)  btn.textContent  = _running  ? '⏸' : '▶';
    if (sc)   sc.textContent   = String(_sessions);

    if (disp) disp.classList.toggle('bep-timer-pulse', _seconds <= 10 && _running);
  }

  function tick() {
    _seconds--;
    updateDisplay();

    if (_seconds > 0) return;

    clearInterval(_interval);
    _running = false;

    if (!_isBreak) {
      _sessions++;
      notify('☕ Break time!', 'Focus session done — take a breather.');
      BEP.toast('✅ Focus session complete! Take a break.', 'success', 5000);
      _isBreak = true;
      _seconds = breakSecs();
    } else {
      notify('🎯 Back to work!', 'Break over — let\'s go!');
      BEP.toast('⚡ Break over! Time to focus.', 'info', 4000);
      _isBreak = false;
      _seconds = workSecs();
    }

    updateDisplay();
  }

  function startTimer() {
    if (_running) { pauseTimer(); return; }
    if (_seconds <= 0) _seconds = workSecs();
    _running = true;
    _interval = setInterval(tick, 1000);
    updateDisplay();
  }

  function pauseTimer() {
    clearInterval(_interval);
    _running = false;
    updateDisplay();
  }

  function resetTimer() {
    pauseTimer();
    _isBreak = false;
    _seconds = workSecs();
    updateDisplay();
  }

  function notify(title, body) {
    try {
      chrome.runtime.sendMessage({ type: 'BEP_NOTIFICATION', title, body });
    } catch {}
  }

  function init() {
    if (_inited) { updateDisplay(); return; }
    _inited  = true;
    _seconds = workSecs();
    updateDisplay();

    document.getElementById('bep-timer-start')?.addEventListener('click', startTimer);
    document.getElementById('bep-timer-reset')?.addEventListener('click', resetTimer);

    // Timer config inputs (already in sidebar HTML, just sync values)
    const cfgWork  = document.getElementById('bep-cfg-work');
    const cfgBreak = document.getElementById('bep-cfg-break');
    if (cfgWork)  cfgWork.value  = String(BEP.settings.timerWork  || 25);
    if (cfgBreak) cfgBreak.value = String(BEP.settings.timerBreak || 5);

    cfgWork?.addEventListener('change', () => {
      BEP.save({ timerWork: parseInt(cfgWork.value) || 25 });
      if (!_running) resetTimer();
    });
    cfgBreak?.addEventListener('change', () => {
      BEP.save({ timerBreak: parseInt(cfgBreak.value) || 5 });
    });
  }

  // Exposed for sidebar.js check — returns boolean
  function isRunning() { return _running; }

  return { init, reset: resetTimer, isRunning };
})();

// modules/settings-panel.js — BetterEP+ v3
window.BEP = window.BEP || {};

BEP.settingsPanel = (() => {
  const THEMES = [
    { id:'default',  label:'Default',  a:'#4f8ef7', b:'#7c5cbf' },
    { id:'ocean',    label:'Ocean',    a:'#00b4d8', b:'#0077b6' },
    { id:'forest',   label:'Forest',   a:'#52b788', b:'#2d6a4f' },
    { id:'sunset',   label:'Sunset',   a:'#f77f00', b:'#d62828' },
    { id:'candy',    label:'Candy',    a:'#f72585', b:'#7209b7' },
    { id:'midnight', label:'Midnight', a:'#a78bfa', b:'#6d28d9' },
    { id:'rose',     label:'Rose',     a:'#fb7185', b:'#e11d48' },
    { id:'amber',    label:'Amber',    a:'#fbbf24', b:'#d97706' },
  ];

  const FONTS = [
    'Geist','Inter','Plus Jakarta Sans','DM Sans','Nunito',
    'Poppins','Outfit','Space Grotesk','Sora','Raleway',
  ];

  // Gradient swatches: no external images, CSP-safe
  // Each has a display gradient and a representative Unsplash URL
  const WALLPAPERS = [
    { name:'Mountains', grad:'linear-gradient(135deg,#667eea,#764ba2)', url:'https://images.unsplash.com/photo-1519681393784-d120267933ba?w=1920&q=80' },
    { name:'Peaks',     grad:'linear-gradient(135deg,#f093fb,#f5576c)', url:'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=1920&q=80' },
    { name:'Night',     grad:'linear-gradient(135deg,#0c0c0c,#1a1a2e)',  url:'https://images.unsplash.com/photo-1475924156734-496f6cac6ec1?w=1920&q=80' },
    { name:'Forest',    grad:'linear-gradient(135deg,#134e5e,#71b280)', url:'https://images.unsplash.com/photo-1536152470836-b943b246224c?w=1920&q=80' },
    { name:'Aurora',    grad:'linear-gradient(135deg,#0f2027,#203a43,#2c5364)', url:'https://images.unsplash.com/photo-1462275646964-a0e3386b89fa?w=1920&q=80' },
    { name:'Pastel',    grad:'linear-gradient(135deg,#ffecd2,#fcb69f)', url:'https://images.unsplash.com/photo-1557682250-33bd709cbe85?w=1920&q=80' },
  ];

  function buildHTML() {
    const s = BEP.settings;
    return `
      <!-- APPEARANCE -->
      <div class="bep-settings-section">
        <div class="bep-settings-section-title">🎨 Appearance</div>
        <div class="bep-setting-row">
          <div class="bep-setting-label">Dark Mode</div>
          <label class="bep-switch"><input type="checkbox" data-key="darkMode" ${s.darkMode?'checked':''}><span class="bep-switch-track"></span></label>
        </div>
        <div class="bep-setting-row">
          <div class="bep-setting-label">Compact Mode</div>
          <label class="bep-switch"><input type="checkbox" data-key="compactMode" ${s.compactMode?'checked':''}><span class="bep-switch-track"></span></label>
        </div>
        <div class="bep-setting-row">
          <div class="bep-setting-label">Animations</div>
          <label class="bep-switch"><input type="checkbox" data-key="animationsEnabled" ${s.animationsEnabled!==false?'checked':''}><span class="bep-switch-track"></span></label>
        </div>
        <div class="bep-setting-row">
          <div class="bep-setting-label">Accent Colour</div>
          <input type="color" data-key="accentColor" value="${s.accentColor||'#4f8ef7'}">
        </div>
        <div class="bep-sub-label">Theme</div>
        <div class="bep-theme-grid">
          ${THEMES.map(t=>`
            <div class="bep-theme-chip ${s.theme===t.id?'active':''}" data-theme="${t.id}"
                 style="background:linear-gradient(135deg,${t.a},${t.b})" title="${t.label}">
              ${t.label}
            </div>
          `).join('')}
        </div>
      </div>

      <!-- FONT -->
      <div class="bep-settings-section">
        <div class="bep-settings-section-title">🔤 Font</div>
        <div class="bep-setting-row">
          <div class="bep-setting-label">Custom Font</div>
          <label class="bep-switch"><input type="checkbox" data-key="fontOverride" ${s.fontOverride?'checked':''}><span class="bep-switch-track"></span></label>
        </div>
        <div class="bep-sub-label">Font Family</div>
        <select data-key="fontFamily" class="bep-select">
          ${FONTS.map(f=>`<option value="${f}" ${s.fontFamily===f?'selected':''}>${f}</option>`).join('')}
        </select>
        <div class="bep-sub-label">Size — <span id="bep-font-scale-val">${Math.round((s.fontScale||1)*100)}%</span></div>
        <input type="range" data-key="fontScale" min="0.8" max="1.3" step="0.05" value="${s.fontScale||1}">
      </div>

      <!-- WALLPAPER -->
      <div class="bep-settings-section">
        <div class="bep-settings-section-title">🖼 Wallpaper</div>
        <div class="bep-sub-label">Image URL</div>
        <input type="text" data-key="wallpaperUrl" class="bep-input" placeholder="https://…" value="${s.wallpaperUrl||''}">
        <div class="bep-sub-label">Overlay — <span id="bep-overlay-val">${Math.round((s.wallpaperOverlay||0.4)*100)}%</span></div>
        <input type="range" data-key="wallpaperOverlay" min="0" max="0.9" step="0.05" value="${s.wallpaperOverlay||0.4}">
        <div class="bep-sub-label">Quick Picks</div>
        <div class="bep-quick-walls">
          ${WALLPAPERS.map(w=>`
            <div class="bep-quick-wall ${s.wallpaperUrl===w.url?'active':''}"
                 data-wall="${w.url}"
                 style="background:${w.grad}"
                 title="${w.name}">
              <span class="bep-wall-label">${w.name}</span>
            </div>
          `).join('')}
          <div class="bep-quick-wall bep-wall-clear ${!s.wallpaperUrl?'active':''}" data-wall="">✕<br>None</div>
        </div>
      </div>

      <!-- PROFILE PICTURE -->
      <div class="bep-settings-section">
        <div class="bep-settings-section-title">👤 Profile Picture</div>
        <div class="bep-profile-row">
          <div class="bep-pfp-preview" id="bep-pfp-preview"
               style="${s.profilePicUrl?`background-image:url(${s.profilePicUrl})`:''}">
            ${!s.profilePicUrl?'👤':''}
          </div>
          <div class="bep-pfp-right">
            <div class="bep-sub-label">Image URL</div>
            <input type="text" data-key="profilePicUrl" class="bep-input" id="bep-pfp-input"
                   placeholder="https://…" value="${s.profilePicUrl||''}">
            <div class="bep-sub-label" style="margin-top:6px">Shape</div>
            <div class="bep-pfp-shapes">
              <div class="bep-pfp-shape ${(s.profilePicShape||'circle')==='circle'?'active':''}"  data-shape="circle"  style="border-radius:50%"></div>
              <div class="bep-pfp-shape ${s.profilePicShape==='rounded'?'active':''}" data-shape="rounded" style="border-radius:8px"></div>
              <div class="bep-pfp-shape ${s.profilePicShape==='square'?'active':''}"  data-shape="square"  style="border-radius:0"></div>
            </div>
          </div>
        </div>
      </div>

      <!-- FEATURES -->
      <div class="bep-settings-section">
        <div class="bep-settings-section-title">✨ Features</div>
        <div class="bep-setting-row">
          <div class="bep-setting-label">Focus Mode</div>
          <label class="bep-switch"><input type="checkbox" data-key="focusMode" ${s.focusMode?'checked':''}><span class="bep-switch-track"></span></label>
        </div>
        <div class="bep-setting-row">
          <div class="bep-setting-label">Points Toast</div>
          <label class="bep-switch"><input type="checkbox" data-key="showPointsToast" ${s.showPointsToast!==false?'checked':''}><span class="bep-switch-track"></span></label>
        </div>
        <div class="bep-setting-row">
          <div class="bep-setting-label">Task Notifications</div>
          <label class="bep-switch"><input type="checkbox" data-key="taskNotifications" ${s.taskNotifications!==false?'checked':''}><span class="bep-switch-track"></span></label>
        </div>
        <div class="bep-setting-row">
          <div class="bep-setting-label">Motivational Quotes</div>
          <label class="bep-switch"><input type="checkbox" data-key="motivationalQuotes" ${s.motivationalQuotes!==false?'checked':''}><span class="bep-switch-track"></span></label>
        </div>
      </div>

      <!-- CUSTOM CSS -->
      <div class="bep-settings-section">
        <div class="bep-settings-section-title">🛠 Custom CSS</div>
        <textarea class="bep-css-editor" data-key="customCSS" placeholder="/* your CSS here */">${s.customCSS||''}</textarea>
      </div>

      <!-- RESET -->
      <div class="bep-settings-section">
        <div class="bep-settings-section-title" style="color:#ef4444">⚠️ Reset</div>
        <button class="bep-danger-btn" id="bep-reset-all">Reset all BetterEP+ settings</button>
      </div>
    `;
  }

  function bindAll(container) {
    // Checkboxes
    container.querySelectorAll('input[type="checkbox"][data-key]').forEach(cb => {
      cb.addEventListener('change', () => {
        BEP.save({ [cb.dataset.key]: cb.checked });
        BEP.emit('settingsChanged', null);
      });
    });

    // Color pickers
    container.querySelectorAll('input[type="color"][data-key]').forEach(el => {
      el.addEventListener('input', () => {
        BEP.save({ [el.dataset.key]: el.value });
        BEP.emit('settingsChanged', null);
      });
    });

    // Text inputs — debounced
    container.querySelectorAll('input[type="text"][data-key], textarea[data-key]').forEach(inp => {
      let t;
      inp.addEventListener('input', () => {
        clearTimeout(t);
        t = setTimeout(() => {
          BEP.save({ [inp.dataset.key]: inp.value });
          BEP.emit('settingsChanged', null);
          if (inp.dataset.key === 'profilePicUrl') updatePfpPreview(inp.value);
        }, 400);
      });
    });

    // Range sliders
    container.querySelectorAll('input[type="range"][data-key]').forEach(r => {
      r.addEventListener('input', () => {
        const val = parseFloat(r.value);
        BEP.save({ [r.dataset.key]: val });
        BEP.emit('settingsChanged', null);
        if (r.dataset.key === 'wallpaperOverlay') {
          const lbl = document.getElementById('bep-overlay-val');
          if (lbl) lbl.textContent = `${Math.round(val*100)}%`;
        }
        if (r.dataset.key === 'fontScale') {
          const lbl = document.getElementById('bep-font-scale-val');
          if (lbl) lbl.textContent = `${Math.round(val*100)}%`;
        }
      });
    });

    // Selects
    container.querySelectorAll('select[data-key]').forEach(sel => {
      sel.addEventListener('change', () => {
        BEP.save({ [sel.dataset.key]: sel.value });
        BEP.emit('settingsChanged', null);
      });
    });

    // Theme chips
    container.querySelectorAll('.bep-theme-chip').forEach(chip => {
      chip.addEventListener('click', () => {
        const id = chip.dataset.theme;
        // Find the matching theme to also set accent colours
        const themeData = THEMES.find(t => t.id === id);
        container.querySelectorAll('.bep-theme-chip').forEach(c => c.classList.remove('active'));
        chip.classList.add('active');
        const patch = { theme: id };
        if (themeData && id !== 'default') {
          patch.accentColor  = themeData.a;
          patch.accentColor2 = themeData.b;
        } else {
          patch.accentColor  = '#4f8ef7';
          patch.accentColor2 = '#7c5cbf';
        }
        BEP.save(patch);
        // Update color input to reflect theme
        const colorInput = container.querySelector('[data-key="accentColor"]');
        if (colorInput) colorInput.value = patch.accentColor;
        BEP.emit('settingsChanged', null);
      });
    });

    // Wallpaper quick picks
    container.querySelectorAll('.bep-quick-wall').forEach(w => {
      w.addEventListener('click', () => {
        const url = w.dataset.wall;
        const inp = container.querySelector('[data-key="wallpaperUrl"]');
        if (inp) inp.value = url;
        BEP.save({ wallpaperUrl: url });
        container.querySelectorAll('.bep-quick-wall').forEach(x => x.classList.remove('active'));
        w.classList.add('active');
        BEP.emit('settingsChanged', null);
      });
    });

    // Profile pic shape
    container.querySelectorAll('.bep-pfp-shape').forEach(sh => {
      sh.addEventListener('click', () => {
        container.querySelectorAll('.bep-pfp-shape').forEach(x => x.classList.remove('active'));
        sh.classList.add('active');
        BEP.save({ profilePicShape: sh.dataset.shape });
        BEP.emit('settingsChanged', null);
        BEP.profilePic.apply();
      });
    });

    // Reset
    document.getElementById('bep-reset-all')?.addEventListener('click', () => {
      if (!confirm('Reset ALL BetterEP+ settings to defaults?')) return;
      BEP.settings = { ...BEP.DEFAULTS };
      BEP.save();
      mount();
      BEP.emit('settingsChanged', null);
      BEP.toast('Settings reset to defaults.', 'info');
    });
  }

  function updatePfpPreview(url) {
    const p = document.getElementById('bep-pfp-preview');
    if (!p) return;
    if (url) { p.style.backgroundImage = `url(${url})`; p.textContent = ''; }
    else     { p.style.backgroundImage = ''; p.textContent = '👤'; }
  }

  function syncValues() {
    const s         = BEP.settings;
    const container = document.getElementById('bep-settings-body');
    if (!container) return;

    container.querySelectorAll('input[type="checkbox"][data-key]').forEach(cb => {
      const v = s[cb.dataset.key];
      cb.checked = v === undefined ? true : !!v;
    });
    container.querySelectorAll('input[type="color"][data-key]').forEach(el => {
      el.value = s[el.dataset.key] || '#4f8ef7';
    });
    container.querySelectorAll('input[type="range"][data-key]').forEach(r => {
      r.value = s[r.dataset.key] ?? r.value;
    });
    container.querySelectorAll('.bep-theme-chip').forEach(c => {
      c.classList.toggle('active', c.dataset.theme === (s.theme || 'default'));
    });
    container.querySelectorAll('.bep-quick-wall').forEach(w => {
      w.classList.toggle('active', w.dataset.wall === (s.wallpaperUrl || ''));
    });
    container.querySelectorAll('.bep-pfp-shape').forEach(sh => {
      sh.classList.toggle('active', sh.dataset.shape === (s.profilePicShape || 'circle'));
    });
    const el1 = document.getElementById('bep-font-scale-val');
    if (el1) el1.textContent = `${Math.round((s.fontScale||1)*100)}%`;
    const el2 = document.getElementById('bep-overlay-val');
    if (el2) el2.textContent = `${Math.round((s.wallpaperOverlay||0.4)*100)}%`;
  }

  function mount() {
    const container = document.getElementById('bep-settings-body');
    if (!container) return;
    container.innerHTML = buildHTML();
    bindAll(container);
  }

  return { mount, syncValues };
})();

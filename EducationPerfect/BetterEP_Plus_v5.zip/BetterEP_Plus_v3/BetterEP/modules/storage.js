// modules/storage.js — BetterEP+ Shared Settings Store
window.BEP = window.BEP || {};

BEP.DEFAULTS = {
  enabled: true,
  darkMode: false,
  theme: 'default',
  accentColor: '#4f8ef7',
  accentColor2: '#7c5cbf',
  wallpaperUrl: '',
  wallpaperType: 'image',
  wallpaperOverlay: 0.4,
  fontFamily: 'Geist',
  fontScale: 1.0,
  compactMode: false,
  focusMode: false,
  quickBar: true,
  taskNotifications: true,
  showPointsToast: true,
  profilePicUrl: '',
  profilePicShape: 'circle',
  hiddenNavItems: [],
  customCSS: '',
  timerWork: 25,
  timerBreak: 5,
  summaryPanel: true,
  motivationalQuotes: true,
  subjectColors: {},
  animationsEnabled: true,
  sidebarCollapsed: false,
};

BEP.settings = { ...BEP.DEFAULTS };

BEP.load = (cb) => {
  try {
    chrome.storage.sync.get('bepSettings', (data) => {
      if (data?.bepSettings) BEP.settings = { ...BEP.DEFAULTS, ...data.bepSettings };
      if (cb) cb(BEP.settings);
    });
  } catch {
    try {
      const s = localStorage.getItem('bepSettings');
      if (s) BEP.settings = { ...BEP.DEFAULTS, ...JSON.parse(s) };
    } catch {}
    if (cb) cb(BEP.settings);
  }
};

BEP.save = (patch) => {
  if (patch) BEP.settings = { ...BEP.settings, ...patch };
  try {
    chrome.storage.sync.set({ bepSettings: BEP.settings });
  } catch {
    localStorage.setItem('bepSettings', JSON.stringify(BEP.settings));
  }
};

BEP.on = (event, handler) => {
  document.addEventListener(`bep:${event}`, (e) => handler(e.detail));
};

BEP.emit = (event, detail) => {
  document.dispatchEvent(new CustomEvent(`bep:${event}`, { detail }));
};

BEP.toast = (msg, type = 'info', duration = 3000) => {
  let container = document.getElementById('bep-toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'bep-toast-container';
    document.body.appendChild(container);
  }
  const toast = document.createElement('div');
  toast.className = `bep-toast bep-toast--${type}`;
  toast.innerHTML = msg;
  container.appendChild(toast);
  requestAnimationFrame(() => toast.classList.add('show'));
  setTimeout(() => {
    toast.classList.remove('show');
    setTimeout(() => toast.remove(), 400);
  }, duration);
};

BEP.waitFor = (sel, cb, timeout = 15000) => {
  const el = document.querySelector(sel);
  if (el) { cb(el); return; }
  const start = Date.now();
  const obs = new MutationObserver(() => {
    const found = document.querySelector(sel);
    if (found) { obs.disconnect(); cb(found); }
    else if (Date.now() - start > timeout) obs.disconnect();
  });
  obs.observe(document.documentElement, { childList: true, subtree: true });
};

BEP.log = (...args) => console.log('%c[BetterEP+]', 'color:#4f8ef7;font-weight:bold', ...args);
BEP.log('Storage module loaded');
